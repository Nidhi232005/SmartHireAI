"""
tests/test_ai_pipeline.py
---------------------------
Unit tests for the AI/NLP pipeline (ai/ package). These tests exercise
each module independently of Flask/MySQL, in line with the project's
decoupled design: text cleaning, feature extraction, TF-IDF/cosine
similarity, semantic (LSA) similarity, and ranking logic.

Run with:
    pytest
or
    python -m pytest tests/ -v
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai.preprocess import clean_text
from ai.feature_extraction import extract_all_features, extract_email, extract_phone
from ai.similarity import compute_match_scores, compute_skill_match, compute_final_score
from ai.semantic_similarity import compute_semantic_scores
from ai.ranking import recommend_rule_based, rank_candidates


# ---------------------------------------------------------------------
# preprocess.py
# ---------------------------------------------------------------------
def test_clean_text_lowercases_and_strips_punctuation():
    result = clean_text("Hello, World! Python's GREAT.")
    assert result == result.lower()
    assert "," not in result and "!" not in result


def test_clean_text_removes_stopwords():
    result = clean_text("this is a test of the stopword removal system")
    assert "is" not in result.split()
    assert "the" not in result.split()


def test_clean_text_handles_empty_input():
    assert clean_text("") == ""
    assert clean_text(None) == ""


# ---------------------------------------------------------------------
# feature_extraction.py
# ---------------------------------------------------------------------
def test_extract_email_finds_valid_email():
    text = "Contact me at jane.doe@example.com for more details."
    assert extract_email(text) == "jane.doe@example.com"


def test_extract_phone_finds_10_digit_number():
    text = "Reach me at 9876543210 anytime."
    assert extract_phone(text) == "9876543210"


def test_extract_all_features_returns_expected_keys():
    sample_resume = (
        "John Smith\n"
        "john.smith@example.com | 9876543210\n"
        "Education: B.Tech Computer Science\n"
        "3 years of experience in Python, Flask, MySQL, Git, Docker.\n"
        "Certified AWS Solutions Architect.\n"
    )
    features = extract_all_features(sample_resume)
    for key in ("name", "email", "phone", "education", "experience", "skills_flat"):
        assert key in features
    assert "python" in features["skills_flat"]
    assert features["email"] == "john.smith@example.com"


# ---------------------------------------------------------------------
# similarity.py (TF-IDF + Cosine Similarity)
# ---------------------------------------------------------------------
def test_compute_match_scores_ranks_relevant_resume_higher():
    job_description = "Looking for a Python Flask developer with MySQL and REST API experience."
    resumes = [
        "Experienced Python Flask developer skilled in MySQL, REST API design, and Git.",
        "Graphic designer skilled in Photoshop, Illustrator, and branding.",
    ]
    scores = compute_match_scores(job_description, resumes)
    assert len(scores) == 2
    assert scores[0] > scores[1]


def test_compute_match_scores_empty_input():
    assert compute_match_scores("some job description", []) == []


def test_compute_skill_match_percentage():
    result = compute_skill_match("Python, Flask, MySQL, Git", ["python", "flask", "docker"])
    assert result["percentage"] == 50.0
    assert "python" in result["matched"] and "flask" in result["matched"]
    assert "mysql" in result["missing"] and "git" in result["missing"]


def test_compute_final_score_blends_components():
    score = compute_final_score(cosine_score=80, skill_score=60, cosine_weight=0.6, skill_weight=0.4)
    assert score == 72.0


# ---------------------------------------------------------------------
# semantic_similarity.py (LSA)
# ---------------------------------------------------------------------
def test_compute_semantic_scores_returns_correct_length():
    job_description = "Data scientist with experience in machine learning and Python."
    resumes = [
        "Machine learning engineer with strong Python and statistics background.",
        "Sales executive with expertise in client relationship management.",
    ]
    scores = compute_semantic_scores(job_description, resumes)
    assert len(scores) == 2
    assert all(0 <= s <= 100 for s in scores)


# ---------------------------------------------------------------------
# ranking.py
# ---------------------------------------------------------------------
def test_recommend_rule_based_thresholds():
    assert recommend_rule_based(75) == "SHORTLIST"
    assert recommend_rule_based(50) == "REVIEW"
    assert recommend_rule_based(20) == "REJECT"


def test_rank_candidates_orders_by_score_descending():
    candidates = [
        {"candidate_id": 1, "final_score": 40},
        {"candidate_id": 2, "final_score": 90},
        {"candidate_id": 3, "final_score": 65},
    ]
    ranked = rank_candidates(candidates)
    assert [c["candidate_id"] for c in ranked] == [2, 3, 1]
    assert [c["rank"] for c in ranked] == [1, 2, 3]
