"""
database.py
-----------
Thin wrapper around pymongo that gives the rest of the application a MongoDB database interface,
utilizing auto-incrementing integer IDs via a counters collection to remain compatible with
Flask routes, and a compatibility run_query SQL translation layer to avoid modifying app.py.
"""

import logging
from datetime import datetime, timedelta
from pymongo import MongoClient, ReturnDocument
from config import Config

logger = logging.getLogger("resumeai.database")

_client = None

def get_client():
    global _client
    if _client is None:
        _client = MongoClient(Config.MONGO_URI)
    return _client

def get_db():
    return get_client()[Config.MONGO_DB]

def get_next_sequence_value(sequence_name):
    """
    Simulates auto-incrementing integer IDs using a counters collection.
    """
    db = get_db()
    result = db.counters.find_one_and_update(
        {"_id": sequence_name},
        {"$inc": {"sequence_value": 1}},
        upsert=True,
        return_document=ReturnDocument.AFTER
    )
    return result["sequence_value"]

def run_query(query, params=None, fetch=False, fetch_one=False, commit=False):
    """
    Translates SQL query string into MongoDB PyMongo operations.
    This translation layer allows app.py to remain unmodified.
    """
    db = get_db()
    params = params or ()
    
    # Normalize query string for pattern matching
    q_norm = " ".join(query.split()).strip()
    q_upper = q_norm.upper()
    
    result = None

    try:
        # 1. AUTH & USER MANAGEMENT
        if q_upper.startswith("SELECT USER_ID, FULL_NAME, EMAIL, COMPANY_NAME, ROLE FROM USERS WHERE USER_ID = %S"):
            res = db.users.find_one({"user_id": int(params[0])})
            if res:
                res = dict(res)
                res.pop("_id", None)
            result = res

        elif q_upper.startswith("INSERT INTO CANDIDATE_STATUS_HISTORY"):
            hist_id = get_next_sequence_value("history_id")
            db.candidate_status_history.insert_one({
                "history_id": hist_id,
                "candidate_id": int(params[0]),
                "old_status": params[1],
                "new_status": params[2],
                "changed_at": datetime.now()
            })
            result = hist_id

        elif q_upper.startswith("SELECT USER_ID FROM USERS WHERE EMAIL = %S"):
            res = db.users.find_one({"email": params[0]}, {"user_id": 1})
            if res:
                res = dict(res)
                res.pop("_id", None)
            result = res

        elif q_upper.startswith("INSERT INTO USERS"):
            uid = get_next_sequence_value("user_id")
            # Params: (full_name, email, password_hash, company_name, role) or (full_name, email, password_hash, company_name)
            # Default role is 'HR'
            role = params[4] if len(params) > 4 else "HR"
            db.users.insert_one({
                "user_id": uid,
                "full_name": params[0],
                "email": params[1],
                "password_hash": params[2],
                "company_name": params[3],
                "role": role,
                "reset_token": None,
                "reset_expires": None,
                "created_at": datetime.now()
            })
            result = uid

        elif q_upper.startswith("SELECT * FROM USERS WHERE EMAIL = %S"):
            res = db.users.find_one({"email": params[0]})
            if res:
                res = dict(res)
                res.pop("_id", None)
            result = res

        elif q_upper.startswith("UPDATE USERS SET RESET_TOKEN = %S, RESET_EXPIRES = %S WHERE USER_ID = %S"):
            db.users.update_one(
                {"user_id": int(params[2])},
                {"$set": {"reset_token": params[0], "reset_expires": params[1]}}
            )
            result = True

        elif q_upper.startswith("SELECT USER_ID FROM USERS WHERE RESET_TOKEN = %S AND RESET_EXPIRES > %S"):
            res = db.users.find_one({"reset_token": params[0], "reset_expires": {"$gt": params[1]}}, {"user_id": 1})
            if res:
                res = dict(res)
                res.pop("_id", None)
            result = res

        elif q_upper.startswith("UPDATE USERS SET PASSWORD_HASH = %S, RESET_TOKEN = NULL, RESET_EXPIRES = NULL WHERE USER_ID = %S"):
            db.users.update_one(
                {"user_id": int(params[1])},
                {"$set": {"password_hash": params[0], "reset_token": None, "reset_expires": None}}
            )
            result = True

        # 2. JOBS MANAGEMENT
        elif q_upper.startswith("SELECT COUNT(*) AS C FROM JOBS WHERE POSTED_BY = %S AND STATUS='ACTIVE'"):
            count = db.jobs.count_documents({"posted_by": int(params[0]), "status": "ACTIVE"})
            result = {"c": count} if fetch_one else [{"c": count}]

        elif q_upper.startswith("SELECT COUNT(*) AS C FROM JOBS WHERE POSTED_BY = %S"):
            count = db.jobs.count_documents({"posted_by": int(params[0])})
            result = {"c": count} if fetch_one else [{"c": count}]

        elif q_upper.startswith("SELECT COUNT(*) AS C FROM CANDIDATES C JOIN JOBS J ON C.JOB_ID=J.JOB_ID WHERE J.POSTED_BY=%S AND C.STATUS IN ('SHORTLISTED','INTERVIEW','HIRED')"):
            job_ids = [j["job_id"] for j in db.jobs.find({"posted_by": int(params[0])}, {"job_id": 1})]
            count = db.candidates.count_documents({"job_id": {"$in": job_ids}, "status": {"$in": ["SHORTLISTED", "INTERVIEW", "HIRED"]}})
            result = {"c": count} if fetch_one else [{"c": count}]

        elif q_upper.startswith("SELECT COUNT(*) AS C FROM CANDIDATES C JOIN JOBS J ON C.JOB_ID=J.JOB_ID WHERE J.POSTED_BY=%S AND C.STATUS='REJECTED'"):
            job_ids = [j["job_id"] for j in db.jobs.find({"posted_by": int(params[0])}, {"job_id": 1})]
            count = db.candidates.count_documents({"job_id": {"$in": job_ids}, "status": "REJECTED"})
            result = {"c": count} if fetch_one else [{"c": count}]

        elif q_upper.startswith("SELECT COUNT(*) AS C FROM CANDIDATES C JOIN JOBS J ON C.JOB_ID=J.JOB_ID WHERE J.POSTED_BY=%S AND C.STATUS='HIRED'"):
            job_ids = [j["job_id"] for j in db.jobs.find({"posted_by": int(params[0])}, {"job_id": 1})]
            count = db.candidates.count_documents({"job_id": {"$in": job_ids}, "status": "HIRED"})
            result = {"c": count} if fetch_one else [{"c": count}]

        elif q_upper.startswith("SELECT COUNT(*) AS C FROM CANDIDATES C JOIN JOBS J ON C.JOB_ID=J.JOB_ID WHERE J.POSTED_BY=%S"):
            job_ids = [j["job_id"] for j in db.jobs.find({"posted_by": int(params[0])}, {"job_id": 1})]
            count = db.candidates.count_documents({"job_id": {"$in": job_ids}})
            result = {"c": count} if fetch_one else [{"c": count}]

        elif q_upper.startswith("SELECT C.FULL_NAME, C.EMAIL, C.STATUS, C.CREATED_AT, J.JOB_TITLE FROM CANDIDATES C JOIN JOBS J ON C.JOB_ID=J.JOB_ID WHERE J.POSTED_BY=%S ORDER BY C.CREATED_AT DESC LIMIT 6"):
            job_map = {j["job_id"]: j["job_title"] for j in db.jobs.find({"posted_by": int(params[0])}, {"job_id": 1, "job_title": 1})}
            cands = list(db.candidates.find({"job_id": {"$in": list(job_map.keys())}}).sort("created_at", -1).limit(6))
            results = []
            for c in cands:
                c.pop("_id", None)
                c["job_title"] = job_map.get(c["job_id"], "")
                results.append(c)
            result = results

        elif q_upper.startswith("SELECT J.JOB_TITLE, AVG(RS.MATCH_SCORE) AS AVG_SCORE FROM RESUME_SCORES RS JOIN JOBS J ON RS.JOB_ID=J.JOB_ID WHERE J.POSTED_BY=%S GROUP BY J.JOB_ID ORDER BY J.CREATED_AT DESC LIMIT 6"):
            jobs = list(db.jobs.find({"posted_by": int(params[0])}).sort("created_at", -1).limit(6))
            results = []
            for j in jobs:
                scores = list(db.resume_scores.find({"job_id": j["job_id"]}))
                avg = sum(s["match_score"] for s in scores) / len(scores) if scores else 0.0
                results.append({"job_title": j["job_title"], "avg_score": round(avg, 2)})
            result = results

        elif q_upper.startswith("SELECT I.*, C.FULL_NAME, J.JOB_TITLE FROM INTERVIEWS I") and "I.SCHEDULED_AT >= NOW()" in q_upper:
            job_map = {j["job_id"]: j["job_title"] for j in db.jobs.find({"posted_by": int(params[0])}, {"job_id": 1, "job_title": 1})}
            ivs = list(db.interviews.find({
                "job_id": {"$in": list(job_map.keys())},
                "status": "SCHEDULED",
                "scheduled_at": {"$gte": datetime.now()}
            }).sort("scheduled_at", 1).limit(5))
            results = []
            for iv in ivs:
                iv.pop("_id", None)
                cand = db.candidates.find_one({"candidate_id": iv["candidate_id"]}, {"full_name": 1})
                iv["full_name"] = cand["full_name"] if cand else ""
                iv["job_title"] = job_map.get(iv["job_id"], "")
                results.append(iv)
            result = results

        elif "FROM JOBS" in q_upper and "LIKE" in q_upper and "POSTED_BY=" in q_upper:
            search_term = params[1].strip("%")
            regex = {"$regex": search_term, "$options": "i"}
            cond = {
                "posted_by": int(params[0]),
                "$or": [
                    {"job_title": regex},
                    {"company": regex},
                    {"location": regex}
                ]
            }
            res = list(db.jobs.find(cond).sort("created_at", -1))
            for r in res:
                r.pop("_id", None)
            result = res

        elif q_upper.startswith("SELECT * FROM JOBS WHERE POSTED_BY=%S ORDER BY CREATED_AT DESC"):
            res = list(db.jobs.find({"posted_by": int(params[0])}).sort("created_at", -1))
            for r in res:
                r.pop("_id", None)
            result = res

        elif q_upper.startswith("INSERT INTO JOBS"):
            # (posted_by, job_title, company, location, experience_req, required_skills, education, salary, job_description, is_public)
            jid = get_next_sequence_value("job_id")
            db.jobs.insert_one({
                "job_id": jid,
                "posted_by": int(params[0]),
                "job_title": params[1],
                "company": params[2],
                "location": params[3],
                "experience_req": params[4],
                "required_skills": params[5],
                "education": params[6],
                "salary": params[7],
                "job_description": params[8],
                "status": "ACTIVE",
                "is_public": int(params[9]),
                "created_at": datetime.now(),
                "updated_at": datetime.now()
            })
            result = jid

        elif q_upper.startswith("SELECT * FROM JOBS WHERE JOB_ID=%S AND POSTED_BY=%S"):
            res = db.jobs.find_one({"job_id": int(params[0]), "posted_by": int(params[1])})
            if res:
                res = dict(res)
                res.pop("_id", None)
            result = res

        elif q_upper.startswith("UPDATE JOBS SET"):
            db.jobs.update_one(
                {"job_id": int(params[10]), "posted_by": int(params[11])},
                {"$set": {
                    "job_title": params[0],
                    "company": params[1],
                    "location": params[2],
                    "experience_req": params[3],
                    "required_skills": params[4],
                    "education": params[5],
                    "salary": params[6],
                    "job_description": params[7],
                    "status": params[8],
                    "is_public": int(params[9]),
                    "updated_at": datetime.now()
                }}
            )
            result = True

        elif q_upper.startswith("DELETE FROM JOBS WHERE JOB_ID=%S AND POSTED_BY=%S"):
            job_id = int(params[0])
            db.jobs.delete_one({"job_id": job_id, "posted_by": int(params[1])})
            cands = [c["candidate_id"] for c in db.candidates.find({"job_id": job_id}, {"candidate_id": 1})]
            db.candidates.delete_many({"job_id": job_id})
            db.resume_scores.delete_many({"job_id": job_id})
            db.uploaded_resumes.delete_many({"candidate_id": {"$in": cands}})
            db.interviews.delete_many({"job_id": job_id})
            result = True

        elif "FROM JOBS" in q_upper and "COMPANY_NAME" in q_upper and "LIKE" in q_upper and "IS_PUBLIC=1" in q_upper:
            search_term = params[0].strip("%")
            regex = {"$regex": search_term, "$options": "i"}
            cond = {
                "is_public": 1,
                "status": "ACTIVE",
                "$or": [
                    {"job_title": regex},
                    {"company": regex},
                    {"location": regex}
                ]
            }
            jobs = list(db.jobs.find(cond).sort("created_at", -1))
            for j in jobs:
                j.pop("_id", None)
                u = db.users.find_one({"user_id": j["posted_by"]}, {"company_name": 1})
                j["company_name"] = u["company_name"] if u else ""
            result = jobs

        elif q_upper.startswith("SELECT J.*, U.COMPANY_NAME FROM JOBS J JOIN USERS U ON J.POSTED_BY=U.USER_ID WHERE J.IS_PUBLIC=1 AND J.STATUS='ACTIVE' ORDER BY J.CREATED_AT DESC"):
            jobs = list(db.jobs.find({"is_public": 1, "status": "ACTIVE"}).sort("created_at", -1))
            for j in jobs:
                j.pop("_id", None)
                u = db.users.find_one({"user_id": j["posted_by"]}, {"company_name": 1})
                j["company_name"] = u["company_name"] if u else ""
            result = jobs

        elif q_upper.startswith("SELECT * FROM JOBS WHERE JOB_ID=%S AND IS_PUBLIC=1 AND STATUS='ACTIVE'"):
            res = db.jobs.find_one({"job_id": int(params[0]), "is_public": 1, "status": "ACTIVE"})
            if res:
                res = dict(res)
                res.pop("_id", None)
            result = res

        elif q_upper.startswith("INSERT INTO CANDIDATES"):
            cid = get_next_sequence_value("candidate_id")
            # Parse parameters based on source
            source = "PUBLIC_APPLICATION" if "PUBLIC_APPLICATION" in q_upper else "HR_UPLOAD"
            db.candidates.insert_one({
                "candidate_id": cid,
                "job_id": int(params[0]),
                "full_name": params[1],
                "email": params[2],
                "phone": params[3],
                "education": params[4],
                "experience": params[5],
                "skills": params[6],
                "source": source,
                "status": "PENDING",
                "created_at": datetime.now()
            })
            result = cid

        elif q_upper.startswith("INSERT INTO UPLOADED_RESUMES"):
            rid = get_next_sequence_value("resume_id")
            db.uploaded_resumes.insert_one({
                "resume_id": rid,
                "candidate_id": int(params[0]),
                "original_name": params[1],
                "stored_path": params[2],
                "file_type": params[3],
                "raw_text": params[4],
                "uploaded_at": datetime.now()
            })
            result = rid

        elif q_upper.startswith("INSERT INTO RESUME_SCORES"):
            sid = get_next_sequence_value("score_id")
            db.resume_scores.insert_one({
                "score_id": sid,
                "candidate_id": int(params[0]),
                "job_id": int(params[1]),
                "cosine_score": float(params[2]) if params[2] is not None else None,
                "semantic_score": float(params[3]) if params[3] is not None else None,
                "match_score": float(params[4]),
                "skill_match_pct": float(params[5]) if params[5] is not None else None,
                "matched_skills": params[6],
                "missing_skills": params[7],
                "recommendation": params[8],
                "ml_probability": float(params[9]) if params[9] is not None else None,
                "scoring_method": params[10],
                "scored_at": datetime.now()
            })
            result = sid

        elif q_upper.startswith("SELECT SCORE_ID, CANDIDATE_ID, MATCH_SCORE FROM RESUME_SCORES WHERE JOB_ID=%S ORDER BY MATCH_SCORE DESC"):
            scores = list(db.resume_scores.find({"job_id": int(params[0])}, {"score_id": 1, "candidate_id": 1, "match_score": 1}).sort("match_score", -1))
            for s in scores:
                s.pop("_id", None)
            result = scores

        elif q_upper.startswith("UPDATE RESUME_SCORES SET RANK_POSITION=%S WHERE SCORE_ID=%S"):
            db.resume_scores.update_one({"score_id": int(params[1])}, {"$set": {"rank_position": int(params[0])}})
            result = True

        elif "FROM CANDIDATES C LEFT JOIN RESUME_SCORES RS ON C.CANDIDATE_ID = RS.CANDIDATE_ID" in q_upper:
            # Dynamic candidate list filtering query
            job_id = int(params[0])
            cond = {"job_id": job_id}
            
            idx = 1
            if "C.FULL_NAME LIKE" in q_upper:
                search_val = params[1].strip("%")
                cond["$or"] = [
                    {"full_name": {"$regex": search_val, "$options": "i"}},
                    {"email": {"$regex": search_val, "$options": "i"}},
                    {"skills": {"$regex": search_val, "$options": "i"}},
                ]
                idx += 3
            
            if "C.STATUS=" in q_upper:
                cond["status"] = params[idx]
                idx += 1
                
            candidates = list(db.candidates.find(cond))
            results = []
            for c in candidates:
                c.pop("_id", None)
                rs = db.resume_scores.find_one({"candidate_id": c["candidate_id"]})
                row = {
                    "candidate_id": c["candidate_id"],
                    "job_id": c["job_id"],
                    "full_name": c["full_name"],
                    "email": c["email"],
                    "phone": c["phone"],
                    "status": c["status"],
                    "created_at": c["created_at"],
                    "matched_skills": rs["matched_skills"] if rs else None,
                    "missing_skills": rs["missing_skills"] if rs else None,
                    "rank_position": rs["rank_position"] if rs else None,
                    "recommendation": rs["recommendation"] if rs else None,
                    "ml_probability": rs["ml_probability"] if rs else None,
                    "scoring_method": rs["scoring_method"] if rs else None,
                    "match_score": rs["match_score"] if rs else None,
                    "skill_match_pct": rs["skill_match_pct"] if rs else None,
                }
                results.append(row)
                
            # Sorting
            if "ORDER BY RS.MATCH_SCORE DESC" in q_upper:
                results.sort(key=lambda x: x["match_score"] or 0.0, reverse=True)
            elif "ORDER BY C.FULL_NAME ASC" in q_upper:
                results.sort(key=lambda x: x["full_name"] or "")
            else:
                results.sort(key=lambda x: x["created_at"], reverse=True)
            result = results

        elif q_upper.startswith("SELECT C.*, RS.MATCH_SCORE FROM CANDIDATES C LEFT JOIN RESUME_SCORES RS ON C.CANDIDATE_ID = RS.CANDIDATE_ID WHERE C.JOB_ID=%S ORDER BY RS.MATCH_SCORE DESC"):
            candidates = list(db.candidates.find({"job_id": int(params[0])}))
            for c in candidates:
                c.pop("_id", None)
                rs = db.resume_scores.find_one({"candidate_id": c["candidate_id"]}, {"match_score": 1})
                c["match_score"] = rs["match_score"] if rs else None
            candidates.sort(key=lambda x: x["match_score"] or 0.0, reverse=True)
            result = candidates

        elif q_upper.startswith("SELECT C.*, J.JOB_TITLE FROM CANDIDATES C JOIN JOBS J ON C.JOB_ID=J.JOB_ID WHERE C.CANDIDATE_ID=%S"):
            cand = db.candidates.find_one({"candidate_id": int(params[0])})
            if cand:
                cand = dict(cand)
                cand.pop("_id", None)
                job = db.jobs.find_one({"job_id": cand["job_id"]}, {"job_title": 1})
                cand["job_title"] = job["job_title"] if job else ""
                result = cand

        elif q_upper.startswith("UPDATE CANDIDATES SET STATUS=%S WHERE CANDIDATE_ID=%S"):
            db.candidates.update_one({"candidate_id": int(params[1])}, {"$set": {"status": params[0]}})
            result = True

        elif q_upper.startswith("SELECT * FROM UPLOADED_RESUMES WHERE RESUME_ID=%S"):
            res = db.uploaded_resumes.find_one({"resume_id": int(params[0])})
            if res:
                res = dict(res)
                res.pop("_id", None)
            result = res

        elif q_upper.startswith("SELECT * FROM UPLOADED_RESUMES WHERE CANDIDATE_ID=%S") and "ORDER BY UPLOADED_AT DESC" in q_upper:
            res = db.uploaded_resumes.find_one({"candidate_id": int(params[0])}, sort=[("uploaded_at", -1)])
            if res:
                res = dict(res)
                res.pop("_id", None)
            result = res

        elif q_upper.startswith("SELECT C.*, J.JOB_TITLE, J.JOB_ID FROM CANDIDATES C JOIN JOBS J ON C.JOB_ID=J.JOB_ID WHERE C.CANDIDATE_ID=%S AND J.POSTED_BY=%S"):
            cand = db.candidates.find_one({"candidate_id": int(params[0])})
            if cand:
                cand = dict(cand)
                cand.pop("_id", None)
                job = db.jobs.find_one({"job_id": cand["job_id"], "posted_by": int(params[1])}, {"job_title": 1})
                if job:
                    cand["job_title"] = job["job_title"]
                    result = cand

        elif q_upper.startswith("INSERT INTO INTERVIEWS"):
            scheduled_at = params[3]
            if isinstance(scheduled_at, str):
                scheduled_at = datetime.fromisoformat(scheduled_at.replace("Z", "+00:00"))
            
            iid = get_next_sequence_value("interview_id")
            db.interviews.insert_one({
                "interview_id": iid,
                "candidate_id": int(params[0]),
                "job_id": int(params[1]),
                "scheduled_by": int(params[2]),
                "scheduled_at": scheduled_at,
                "mode": params[4],
                "location_or_link": params[5],
                "notes": params[6],
                "status": "SCHEDULED",
                "created_at": datetime.now()
            })
            result = iid

        elif q_upper.startswith("UPDATE CANDIDATES SET STATUS='INTERVIEW' WHERE CANDIDATE_ID=%S"):
            db.candidates.update_one({"candidate_id": int(params[0])}, {"$set": {"status": "INTERVIEW"}})
            result = True

        elif q_upper.startswith("SELECT I.*, C.FULL_NAME, C.EMAIL, J.JOB_TITLE FROM INTERVIEWS I") and "J.POSTED_BY=%S" in q_upper:
            job_map = {j["job_id"]: j["job_title"] for j in db.jobs.find({"posted_by": int(params[0])}, {"job_id": 1, "job_title": 1})}
            ivs = list(db.interviews.find({"job_id": {"$in": list(job_map.keys())}}).sort("scheduled_at", 1))
            results = []
            for iv in ivs:
                iv.pop("_id", None)
                cand = db.candidates.find_one({"candidate_id": iv["candidate_id"]}, {"full_name": 1, "email": 1})
                iv["full_name"] = cand["full_name"] if cand else ""
                iv["email"] = cand["email"] if cand else ""
                iv["job_title"] = job_map.get(iv["job_id"], "")
                results.append(iv)
            result = ivs

        elif q_upper.startswith("SELECT JOB_ID, JOB_TITLE FROM JOBS WHERE POSTED_BY=%S ORDER BY CREATED_AT DESC"):
            jobs = list(db.jobs.find({"posted_by": int(params[0])}, {"job_id": 1, "job_title": 1}).sort("created_at", -1))
            for j in jobs:
                j.pop("_id", None)
            result = jobs

        elif q_upper.startswith("SELECT RS.*, C.FULL_NAME, C.SKILLS, C.STATUS FROM RESUME_SCORES RS") and "RS.JOB_ID=%S" in q_upper:
            scores = list(db.resume_scores.find({"job_id": int(params[0])}).sort("match_score", -1))
            results = []
            for s in scores:
                s.pop("_id", None)
                cand = db.candidates.find_one({"candidate_id": s["candidate_id"]}, {"full_name": 1, "skills": 1, "status": 1})
                s["full_name"] = cand["full_name"] if cand else ""
                s["skills"] = cand["skills"] if cand else ""
                s["status"] = cand["status"] if cand else ""
                results.append(s)
            result = results
            
        else:
            raise NotImplementedError(f"Unsupported SQL query translation: {query}")

        # Post-process return formats
        if fetch_one:
            if isinstance(result, list):
                return result[0] if result else None
            return result
        elif fetch:
            if not isinstance(result, list):
                return [result] if result is not None else []
            return result
        return result

    except Exception:
        logger.exception("Query translation failed: %s with params %s", query, params)
        raise

def init_db():
    """
    Initializes collections, creates unique/regular indexes, and seeds the database
    with sample/demo data if it is empty.
    """
    db = get_db()
    
    # 1. Create Indexes
    db.users.create_index("email", unique=True)
    db.jobs.create_index("job_title")
    db.jobs.create_index("status")
    db.candidates.create_index("job_id")
    db.candidates.create_index("status")
    db.candidate_status_history.create_index("candidate_id")
    db.uploaded_resumes.create_index("candidate_id")
    db.resume_scores.create_index("job_id")
    db.resume_scores.create_index("candidate_id")
    db.interviews.create_index("candidate_id")
    
    # 2. Seed Sample Data if database is brand new (no users)
    if db.users.count_documents({}) == 0:
        logger.info("Database is empty. Seeding sample data...")
        
        # Reset counters
        db.counters.delete_many({})
        db.counters.insert_many([
            {"_id": "user_id", "sequence_value": 0},
            {"_id": "job_id", "sequence_value": 0},
            {"_id": "candidate_id", "sequence_value": 0},
            {"_id": "resume_id", "sequence_value": 0},
            {"_id": "score_id", "sequence_value": 0},
            {"_id": "history_id", "sequence_value": 0},
            {"_id": "interview_id", "sequence_value": 0},
            {"_id": "report_id", "sequence_value": 0},
        ])
        
        # User
        user_id = get_next_sequence_value("user_id")
        db.users.insert_one({
            "user_id": user_id,
            "full_name": "Priya Sharma",
            "email": "hr@demo.com",
            "password_hash": "pbkdf2:sha256:600000$8pYb0rq6qzX8YQaT$e6ef157e2f2f6b3f8a2f6b0b1c9c0e4f6a1e2c3d4b5a6978fcb0a1d2e3f4a5b6",
            "company_name": "BrightTech Solutions",
            "role": "HR",
            "reset_token": None,
            "reset_expires": None,
            "created_at": datetime.now()
        })
        
        # Jobs
        job1_id = get_next_sequence_value("job_id")
        db.jobs.insert_one({
            "job_id": job1_id,
            "posted_by": user_id,
            "job_title": "Python Backend Developer",
            "company": "BrightTech Solutions",
            "location": "Bengaluru, India",
            "experience_req": "2-4 years",
            "required_skills": "Python, Flask, Django, REST API, MySQL, Git, Docker",
            "education": "B.Tech/B.E. in Computer Science or related field",
            "salary": "8-14 LPA",
            "job_description": "We are looking for a skilled Python Backend Developer to design and maintain scalable REST APIs, work with relational databases, and collaborate with the frontend team to deliver robust web applications.",
            "status": "ACTIVE",
            "is_public": 1,
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        })
        
        job2_id = get_next_sequence_value("job_id")
        db.jobs.insert_one({
            "job_id": job2_id,
            "posted_by": user_id,
            "job_title": "Machine Learning Engineer",
            "company": "BrightTech Solutions",
            "location": "Remote",
            "experience_req": "1-3 years",
            "required_skills": "Python, Scikit-learn, TensorFlow, NLP, Pandas, NumPy, Data Preprocessing",
            "education": "M.Tech/MCA/B.Tech in CS, AI or Data Science",
            "salary": "10-18 LPA",
            "job_description": "Seeking a Machine Learning Engineer to build and deploy NLP and ML pipelines, including text classification, similarity scoring, and predictive models for our HR-tech product suite.",
            "status": "ACTIVE",
            "is_public": 1,
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        })
        
        job3_id = get_next_sequence_value("job_id")
        db.jobs.insert_one({
            "job_id": job3_id,
            "posted_by": user_id,
            "job_title": "Frontend Developer (React)",
            "company": "BrightTech Solutions",
            "location": "Pune, India",
            "experience_req": "1-2 years",
            "required_skills": "HTML, CSS, JavaScript, React, Bootstrap, REST API Integration",
            "education": "B.Tech/BCA/MCA",
            "salary": "6-10 LPA",
            "job_description": "Looking for a Frontend Developer to build responsive, accessible interfaces using React and Bootstrap, integrating with backend REST APIs.",
            "status": "ACTIVE",
            "is_public": 1,
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        })
        
        # Candidates
        cand1_id = get_next_sequence_value("candidate_id")
        db.candidates.insert_one({
            "candidate_id": cand1_id,
            "job_id": job1_id,
            "full_name": "Rohit Verma",
            "email": "rohit.verma@example.com",
            "phone": "9876543210",
            "education": "B.Tech Computer Science",
            "experience": "3 years",
            "skills": "Python, Flask, MySQL, REST API, Git, Docker",
            "source": "HR_UPLOAD",
            "status": "SHORTLISTED",
            "created_at": datetime.now()
        })
        
        cand2_id = get_next_sequence_value("candidate_id")
        db.candidates.insert_one({
            "candidate_id": cand2_id,
            "job_id": job1_id,
            "full_name": "Ananya Iyer",
            "email": "ananya.iyer@example.com",
            "phone": "9876501234",
            "education": "M.Tech Computer Science",
            "experience": "2 years",
            "skills": "Python, Django, PostgreSQL, REST API, AWS",
            "source": "HR_UPLOAD",
            "status": "PENDING",
            "created_at": datetime.now()
        })
        
        cand3_id = get_next_sequence_value("candidate_id")
        db.candidates.insert_one({
            "candidate_id": cand3_id,
            "job_id": job2_id,
            "full_name": "Karan Mehta",
            "email": "karan.mehta@example.com",
            "phone": "9123456789",
            "education": "MCA",
            "experience": "2 years",
            "skills": "Python, Scikit-learn, Pandas, NumPy, NLP, TensorFlow",
            "source": "PUBLIC_APPLICATION",
            "status": "INTERVIEW",
            "created_at": datetime.now()
        })
        
        # Resume Scores
        db.resume_scores.insert_many([
            {
                "score_id": get_next_sequence_value("score_id"),
                "candidate_id": cand1_id,
                "job_id": job1_id,
                "cosine_score": 74.10,
                "semantic_score": 68.50,
                "match_score": 78.40,
                "skill_match_pct": 83.33,
                "matched_skills": "Python, Flask, MySQL, REST API, Git, Docker",
                "missing_skills": "Django",
                "rank_position": 1,
                "recommendation": "SHORTLIST",
                "ml_probability": None,
                "scoring_method": "RULE_BASED",
                "scored_at": datetime.now()
            },
            {
                "score_id": get_next_sequence_value("score_id"),
                "candidate_id": cand2_id,
                "job_id": job1_id,
                "cosine_score": 52.00,
                "semantic_score": 49.20,
                "match_score": 55.10,
                "skill_match_pct": 60.00,
                "matched_skills": "Python, REST API",
                "missing_skills": "Flask, MySQL, Git, Docker",
                "rank_position": 2,
                "recommendation": "REVIEW",
                "ml_probability": None,
                "scoring_method": "RULE_BASED",
                "scored_at": datetime.now()
            },
            {
                "score_id": get_next_sequence_value("score_id"),
                "candidate_id": cand3_id,
                "job_id": job2_id,
                "cosine_score": 79.80,
                "semantic_score": 74.10,
                "match_score": 81.25,
                "skill_match_pct": 85.71,
                "matched_skills": "Python, Scikit-learn, Pandas, NumPy, NLP",
                "missing_skills": "TensorFlow",
                "rank_position": 1,
                "recommendation": "SHORTLIST",
                "ml_probability": None,
                "scoring_method": "RULE_BASED",
                "scored_at": datetime.now()
            }
        ])
        
        # Candidate Status History
        db.candidate_status_history.insert_many([
            {
                "history_id": get_next_sequence_value("history_id"),
                "candidate_id": cand1_id,
                "old_status": "PENDING",
                "new_status": "SHORTLISTED",
                "changed_at": datetime.now()
            },
            {
                "history_id": get_next_sequence_value("history_id"),
                "candidate_id": cand3_id,
                "old_status": "PENDING",
                "new_status": "SHORTLISTED",
                "changed_at": datetime.now()
            },
            {
                "history_id": get_next_sequence_value("history_id"),
                "candidate_id": cand3_id,
                "old_status": "SHORTLISTED",
                "new_status": "INTERVIEW",
                "changed_at": datetime.now()
            }
        ])
        
        # Interviews
        db.interviews.insert_one({
            "interview_id": get_next_sequence_value("interview_id"),
            "candidate_id": cand3_id,
            "job_id": job2_id,
            "scheduled_by": user_id,
            "scheduled_at": datetime.now() + timedelta(days=3),
            "mode": "ONLINE",
            "location_or_link": "https://meet.example.com/karan-mehta",
            "notes": "First-round technical interview focusing on NLP projects.",
            "status": "SCHEDULED",
            "created_at": datetime.now()
        })
        logger.info("Sample data seeded successfully!")
