# AI-Based Resume Screening and Recruitment Portal

A full-stack web application that automates resume screening using NLP and
Machine Learning. HR users post jobs, upload candidate resumes (PDF/DOCX or
bulk ZIP), and the system extracts structured resume data, compares each
resume against the job description using **TF-IDF cosine similarity +
LSA-based semantic similarity + skill matching** (with an optional trained
**ML classifier** as a second scoring mode), ranks candidates, and helps
recruiters move them through a full **Kanban hiring pipeline** — including
interview scheduling, candidate self-service applications, and email
notifications.

---

## 1. What's New in This Version

| Area | Addition |
|------|----------|
| AI/ML | Optional Logistic Regression **classifier** (`ai/classifier.py`) trained on a documented synthetic dataset, with saved accuracy/precision/recall/F1/ROC-AUC/confusion-matrix metrics viewable on the **ML Insights** page |
| AI/ML | **Semantic matching mode** using TF-IDF + Truncated SVD (Latent Semantic Analysis) as a lightweight, explainable alternative to literal keyword overlap (`ai/semantic_similarity.py`) |
| Product | **Public Careers page** (`/careers`) where candidates can browse open roles and self-apply — no HR login required |
| Product | **Kanban pipeline board** (`/jobs/<id>/pipeline`) with drag-and-drop status updates (Applied → Pending → Shortlisted → Interview → Hired / Rejected) |
| Product | **Interview scheduling** module with a dedicated interviews list |
| Product | **Bulk ZIP resume upload** in addition to individual file uploads |
| Product | **Email notifications** (Flask-Mail) on candidate status changes (safely disabled by default) |
| Analytics | **Skill-gap analysis** (most commonly missing required skills) and a **hiring funnel** chart on the Reports page |
| Security | **CSRF protection** (Flask-WTF) on every form, **rate limiting** on login (Flask-Limiter), secrets loaded from a `.env` file |
| Engineering | Centralized **logging** to `logs/app.log`, a **pytest** suite for the AI pipeline, and **Docker/Docker Compose** for one-command setup |

---

## 2. Technology Stack

| Layer          | Technology                                                   |
|-----------------|---------------------------------------------------------------|
| Frontend        | HTML5, CSS3, Bootstrap 5, JavaScript (ES6), Chart.js          |
| Backend         | Python 3, Flask, Flask-WTF, Flask-Limiter, Flask-Mail          |
| AI / ML / NLP   | scikit-learn (TF-IDF, Cosine Similarity, TruncatedSVD/LSA, Logistic Regression), NLTK, spaCy (optional) |
| Database        | MySQL                                                          |
| File Parsing    | pdfplumber, python-docx                                        |
| Reports         | ReportLab (PDF export), csv (CSV export)                       |
| Testing         | pytest                                                         |
| Deployment      | Docker, Docker Compose                                         |

---

## 3. Project Structure

```
AI_Resume_Screening_Portal/
├── app.py                        # Main Flask application (all routes)
├── config.py                     # Central configuration (env-driven)
├── database.py                   # MySQL connection pool + query helper
├── requirements.txt
├── .env.example                  # Copy to .env and fill in real values
├── Dockerfile
├── docker-compose.yml
├── pytest.ini
├── database/
│   ├── schema.sql                 # Full schema incl. interviews, status history
│   └── sample_data.sql
├── ai/
│   ├── preprocess.py               # Text extraction (PDF/DOCX) + NLP cleaning
│   ├── feature_extraction.py       # Skills / education / experience extraction
│   ├── similarity.py               # TF-IDF vectorization + cosine similarity
│   ├── semantic_similarity.py      # LSA-based semantic matching mode
│   ├── classifier.py               # ML classifier loading/prediction
│   └── ranking.py                  # Ranking + recommendation logic
├── scripts/
│   └── train_classifier.py         # Trains + evaluates the ML classifier
├── tests/
│   └── test_ai_pipeline.py         # pytest suite for the ai/ package
├── templates/                     # Jinja2 HTML templates (Bootstrap 5 UI)
├── static/
│   ├── css/style.css               # Glassmorphism theme, dark mode, kanban styles
│   └── js/                         # main.js, upload.js, candidates.js, kanban.js
├── uploads/                       # Uploaded resume storage (runtime)
├── models/                        # Trained classifier + saved metrics
├── logs/                          # Application log file
└── README.md
```

---

## 4. Quick Start with Docker (recommended)

```bash
docker compose up --build
```
This starts MySQL (auto-seeded with `schema.sql` + `sample_data.sql`) and
the Flask app together. Visit **http://localhost:5000**.

---

## 5. Manual Installation

### Prerequisites
- Python 3.10+
- MySQL Server 8.0+
- pip

### Step 1 — Install dependencies
```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Step 2 — Download NLTK corpora and spaCy model (one-time)
```bash
python -c "import nltk; [nltk.download(p) for p in ['punkt','punkt_tab','stopwords','wordnet','omw-1.4']]"
python -m spacy download en_core_web_sm
```
> The app falls back to regex-based name extraction if the spaCy model isn't installed.

### Step 3 — Set up MySQL
```bash
mysql -u root -p < database/schema.sql
mysql -u root -p resume_screening_db < database/sample_data.sql   # optional demo data
```

### Step 4 — Configure environment variables
```bash
cp .env.example .env
# then edit .env with your MySQL credentials, SECRET_KEY, etc.
```

### Step 5 — (Optional) Train the ML classifier
```bash
python scripts/train_classifier.py
```
This generates `models/resume_classifier.joblib` and
`models/classifier_metrics.json`. Set `USE_ML_CLASSIFIER=1` in `.env` to
have new resume uploads scored by this model (visible on the **ML
Insights** page) instead of / alongside the rule-based thresholds.

### Step 6 — Run the application
```bash
python app.py
```
Visit **http://localhost:5000**

---

## 6. Demo Login

If you imported `sample_data.sql`:
- **Email:** `hr@demo.com`
- **Password:** `Demo@123`

Public candidates don't need an account — they can apply directly from
**http://localhost:5000/careers**.

---

## 7. Running Tests

```bash
pytest -v
```
Covers text cleaning, feature extraction, TF-IDF/cosine similarity, LSA
semantic similarity, skill matching, and ranking — all independent of
Flask/MySQL, in line with the project's decoupled `ai/` package design.

---

## 8. How the AI Screening Pipeline Works

1. **Resume Upload** — individually, via drag-and-drop, or in bulk via a ZIP archive; also available to the public via the self-service Careers page.
2. **Text Extraction** — `ai/preprocess.py` extracts raw text via `pdfplumber` / `python-docx`.
3. **Text Cleaning** — lowercasing, punctuation/number removal, stop-word removal, tokenization, lemmatization.
4. **Feature Extraction** — `ai/feature_extraction.py` pulls out name, email, phone, education, experience, skills, certifications, and projects.
5. **TF-IDF + Cosine Similarity** — `ai/similarity.py` scores literal textual overlap between job description and resume.
6. **Semantic (LSA) Similarity** — `ai/semantic_similarity.py` reduces the TF-IDF space with Truncated SVD and scores similarity of the underlying "concepts", catching related-but-not-identical wording.
7. **Skill Matching** — required skills are compared against extracted resume skills for an explicit match percentage.
8. **Final Score** — a configurable weighted blend of the three signals above (see `Config.COSINE_WEIGHT` / `SEMANTIC_WEIGHT` / `SKILL_WEIGHT`).
9. **Recommendation** — either fixed thresholds (**RULE_BASED**, default) or a trained Logistic Regression classifier's predicted probability (**ML_CLASSIFIER**, opt-in via `USE_ML_CLASSIFIER=1`) decide Shortlist / Review / Reject.
10. **Ranking** — `ai/ranking.py` sorts candidates by final score within each job.

---

## 9. Key Features

- Secure authentication: registration, login, forgot/reset password, hashed passwords (PBKDF2), session management, CSRF protection, rate-limited login, input validation.
- Modern HR dashboard with stat cards, charts, upcoming interviews, and an ML-scoring status indicator.
- Full job management (create/edit/delete/search), with a public/private toggle per posting.
- **Public Careers page** for candidate self-applications — no HR account needed.
- Drag-and-drop **and** bulk ZIP resume upload with validation and progress feedback.
- AI-powered resume screening: TF-IDF cosine similarity, LSA semantic similarity, skill overlap, and an optional trained ML classifier.
- **ML Insights page** showing live accuracy/precision/recall/F1/ROC-AUC and a confusion matrix for full transparency.
- **Kanban hiring pipeline** with drag-and-drop status changes, backed by a full status-history audit trail.
- **Interview scheduling** with a dedicated upcoming-interviews list.
- Email notifications on status changes (safe no-op when unconfigured).
- Reports module with CSV/PDF export, skill-gap analysis, and a hiring funnel chart.
- Responsive, glassmorphism-themed UI with dark mode toggle.
- Dockerized for one-command local deployment.

---

## 10. Database Schema Overview

| Table                        | Purpose                                                        |
|-------------------------------|------------------------------------------------------------------|
| `users`                       | HR/Admin accounts                                                 |
| `jobs`                        | Job postings (with a public/private flag for the Careers page)   |
| `candidates`                  | Parsed candidate info; status models the full Kanban pipeline    |
| `candidate_status_history`    | Every status transition, timestamped, for funnel/time-to-hire analytics |
| `uploaded_resumes`            | Raw uploaded files + extracted text                               |
| `resume_scores`                | Cosine/semantic/skill/final scores, ML probability, recommendation |
| `interviews`                   | Scheduled interviews per candidate                                |
| `reports`                      | Saved/exported hiring report summaries                            |

---

## 11. Notes for Viva / Presentation

- The `ai/` package is fully decoupled from Flask and MySQL — every module can be demoed and tested independently (see `tests/test_ai_pipeline.py`).
- `scripts/train_classifier.py` is a good live-demo script: it prints accuracy/precision/recall/F1/ROC-AUC and a confusion matrix in ~5 seconds, and the same numbers appear on the **ML Insights** page.
- `config.py` centralizes every tunable parameter (scoring weights, thresholds, feature flags) so behavior can be explained and adjusted live.
- The Kanban board (`static/js/kanban.js`) demonstrates AJAX + CSRF-protected state changes without a page reload — a good talking point for the "web development" half of the viva.
- `docker compose up --build` is the fastest way to demonstrate the full system on an examiner's machine without a manual MySQL setup.
