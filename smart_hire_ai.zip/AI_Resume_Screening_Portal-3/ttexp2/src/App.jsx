import React, { useState, useEffect } from "react";
import { HashRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ProtectedRoute from "./components/ProtectedRoute";

// Pages
import Registration from "./pages/Registration";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Jobs from "./pages/Jobs";
import Applications from "./pages/Applications";
import Profile from "./pages/Profile";

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [appliedJobs, setAppliedJobs] = useState([]);
  const [savedJobIds, setSavedJobIds] = useState([]);
  const [loading, setLoading] = useState(true);

  // Load user session on mount
  useEffect(() => {
    // Seed default user for testing if no users exist
    const existingUsers = localStorage.getItem("users");
    if (!existingUsers) {
      const defaultUsers = [
        {
          name: "Alex Carter",
          email: "alex@hiresphere.com",
          phone: "9876543210",
          password: "password123",
          gender: "Male",
          location: "Remote",
          skills: ["React", "JavaScript", "HTML5", "CSS3"],
          experience: "2 Years",
          education: "Master of Computer Applications (MCA)",
          summary: "Enthusiastic Frontend Developer with a passion for building premium user interfaces using React and Bootstrap.",
          resumeTitle: "Alex_Carter_Resume.pdf"
        }
      ];
      localStorage.setItem("users", JSON.stringify(defaultUsers));
    }

    const savedUser = localStorage.getItem("currentUser");
    if (savedUser) {
      const userParsed = JSON.parse(savedUser);
      setCurrentUser(userParsed);
      
      // Load applications and saved jobs specific to this user
      const savedApps = localStorage.getItem(`appliedJobs_${userParsed.email}`);
      const savedIds = localStorage.getItem(`savedJobs_${userParsed.email}`);
      
      if (savedApps) setAppliedJobs(JSON.parse(savedApps));
      if (savedIds) setSavedJobIds(JSON.parse(savedIds));
    }
    setLoading(false);
  }, []);

  // Update localStorage when appliedJobs changes
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(`appliedJobs_${currentUser.email}`, JSON.stringify(appliedJobs));
    }
  }, [appliedJobs, currentUser]);

  // Update localStorage when savedJobIds changes
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(`savedJobs_${currentUser.email}`, JSON.stringify(savedJobIds));
    }
  }, [savedJobIds, currentUser]);

  // Handle user login
  const handleLogin = (user) => {
    setCurrentUser(user);
    localStorage.setItem("currentUser", JSON.stringify(user));
    
    // Load existing user-specific data from localStorage or reset state
    const savedApps = localStorage.getItem(`appliedJobs_${user.email}`);
    const savedIds = localStorage.getItem(`savedJobs_${user.email}`);
    
    setAppliedJobs(savedApps ? JSON.parse(savedApps) : []);
    setSavedJobIds(savedIds ? JSON.parse(savedIds) : []);
  };

  // Handle user logout
  const handleLogout = () => {
    setCurrentUser(null);
    setAppliedJobs([]);
    setSavedJobIds([]);
    localStorage.removeItem("currentUser");
  };

  // Handle updating user profile
  const handleProfileUpdate = (updatedUser) => {
    setCurrentUser(updatedUser);
    localStorage.setItem("currentUser", JSON.stringify(updatedUser));

    // Also update the user in the registered users list in localStorage
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const updatedUsers = users.map((u) => 
      u.email.toLowerCase() === updatedUser.email.toLowerCase() ? updatedUser : u
    );
    localStorage.setItem("users", JSON.stringify(updatedUsers));
  };

  // Handle applying for a job
  const handleApply = (job) => {
    // Check if already applied
    if (appliedJobs.some((app) => app.jobId === job.id)) {
      alert("You have already applied for this job!");
      return;
    }

    const newApplication = {
      id: Date.now(),
      jobId: job.id,
      appliedDate: new Date().toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric"
      }),
      status: "Applied" // default status
    };

    setAppliedJobs((prev) => [newApplication, ...prev]);
    
    // Auto-remove from saved list if it was saved
    setSavedJobIds((prev) => prev.filter((id) => id !== job.id));

    alert(`Successfully applied to ${job.title} at ${job.company}!`);
  };

  // Handle bookmarking/saving a job
  const handleSaveToggle = (jobId) => {
    setSavedJobIds((prev) => {
      const exists = prev.includes(jobId);
      if (exists) {
        return prev.filter((id) => id !== jobId);
      } else {
        return [...prev, jobId];
      }
    });
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center min-vh-100 bg-light">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading HireSphere...</span>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className="d-flex flex-column min-vh-100">
        <Navbar user={currentUser} onLogout={handleLogout} />
        
        <main className="flex-grow-1 main-content bg-light">
          <Routes>
            {/* Public Routes */}
            <Route
              path="/login"
              element={
                currentUser ? <Navigate to="/dashboard" replace /> : <Login onLoginSuccess={handleLogin} />
              }
            />
            <Route
              path="/register"
              element={
                currentUser ? <Navigate to="/dashboard" replace /> : <Registration />
              }
            />

            {/* Protected Routes */}
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Dashboard
                    user={currentUser}
                    appliedJobs={appliedJobs}
                    savedJobIds={savedJobIds}
                    onApply={handleApply}
                    onSave={handleSaveToggle}
                  />
                </ProtectedRoute>
              }
            />
            <Route
              path="/jobs"
              element={
                <ProtectedRoute>
                  <Jobs
                    appliedJobs={appliedJobs}
                    savedJobIds={savedJobIds}
                    onApply={handleApply}
                    onSave={handleSaveToggle}
                  />
                </ProtectedRoute>
              }
            />
            <Route
              path="/applications"
              element={
                <ProtectedRoute>
                  <Applications
                    appliedJobs={appliedJobs}
                    savedJobIds={savedJobIds}
                    onApply={handleApply}
                    onRemoveSave={handleSaveToggle}
                  />
                </ProtectedRoute>
              }
            />
            <Route
              path="/profile"
              element={
                <ProtectedRoute>
                  <Profile user={currentUser} onProfileUpdate={handleProfileUpdate} />
                </ProtectedRoute>
              }
            />

            {/* Default Navigation Redirects */}
            <Route
              path="*"
              element={<Navigate to={currentUser ? "/dashboard" : "/login"} replace />}
            />
          </Routes>
        </main>

        <Footer />
      </div>
    </Router>
  );
}
