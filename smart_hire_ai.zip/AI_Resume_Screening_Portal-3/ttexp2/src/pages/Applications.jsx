import React, { useState } from "react";
import { Link } from "react-router-dom";
import { sampleJobs } from "../data/jobs";

export default function Applications({
  appliedJobs,
  savedJobIds,
  onApply,
  onRemoveSave
}) {
  const [activeTab, setActiveTab] = useState("applied"); // 'applied' or 'saved'
  const [searchQuery, setSearchQuery] = useState("");

  // Get saved job list
  const savedJobs = sampleJobs.filter((job) => savedJobIds.includes(job.id));

  // Search filter for applied jobs
  const filteredApplied = appliedJobs.filter((app) => {
    const job = sampleJobs.find((j) => j.id === app.jobId);
    if (!job) return false;
    const matchString = `${job.title} ${job.company}`.toLowerCase();
    return matchString.includes(searchQuery.toLowerCase());
  });

  // Get badge color based on application status
  const getStatusBadge = (status) => {
    switch (status) {
      case "Applied":
        return <span className="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-2">Applied</span>;
      case "Under Review":
        return <span className="badge bg-info-subtle text-info border border-info-subtle px-3 py-2">Under Review</span>;
      case "Shortlisted":
        return <span className="badge bg-success-subtle text-success border border-success-subtle px-3 py-2">Shortlisted</span>;
      case "Rejected":
        return <span className="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2">Rejected</span>;
      default:
        return <span className="badge bg-secondary-subtle text-secondary px-3 py-2">{status}</span>;
    }
  };

  return (
    <div className="container py-4">
      <h3 className="fw-bold text-dark mb-4">My Career Ledger</h3>

      {/* Tabs Menu */}
      <ul className="nav nav-tabs mb-4" id="careerTabs" role="tablist">
        <li className="nav-item" role="presentation">
          <button
            className={`nav-link fw-semibold px-4 py-2.5 border-0 bg-transparent text-muted position-relative ${
              activeTab === "applied" ? "active border-bottom border-primary text-primary" : ""
            }`}
            onClick={() => setActiveTab("applied")}
            type="button"
          >
            <i className="bi bi-file-earmark-check me-2"></i>
            Applied Jobs ({appliedJobs.length})
          </button>
        </li>
        <li className="nav-item" role="presentation">
          <button
            className={`nav-link fw-semibold px-4 py-2.5 border-0 bg-transparent text-muted position-relative ${
              activeTab === "saved" ? "active border-bottom border-primary text-primary" : ""
            }`}
            onClick={() => setActiveTab("saved")}
            type="button"
          >
            <i className="bi bi-bookmark-star me-2"></i>
            Saved Jobs ({savedJobs.length})
          </button>
        </li>
      </ul>

      {/* Tab Contents */}
      <div className="tab-content">
        {/* APPLIED JOBS TAB */}
        {activeTab === "applied" && (
          <div className="card border-0 shadow-sm rounded-12 p-4 bg-white">
            <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
              <h5 className="fw-bold mb-0 text-dark">Track Status</h5>
              {appliedJobs.length > 0 && (
                <div className="input-group" style={{ maxWidth: "320px" }}>
                  <span className="input-group-text bg-light border-end-0">
                    <i className="bi bi-search text-muted"></i>
                  </span>
                  <input
                    type="text"
                    className="form-control bg-light border-start-0 ps-0 fs-7.5"
                    placeholder="Search applied jobs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              )}
            </div>

            {appliedJobs.length === 0 ? (
              <div className="text-center py-5">
                <div className="display-3 text-muted mb-3">
                  <i className="bi bi-send-x"></i>
                </div>
                <h5 className="fw-bold text-dark">No Applications Yet</h5>
                <p className="text-muted mb-4 max-w-sm mx-auto">
                  You haven't applied for any jobs yet. Check out the job opportunities page to submit your application.
                </p>
                <Link to="/jobs" className="btn btn-primary-custom px-4">
                  Explore Opportunities
                </Link>
              </div>
            ) : filteredApplied.length === 0 ? (
              <div className="text-center py-4">
                <p className="text-muted">No applications found matching "{searchQuery}"</p>
              </div>
            ) : (
              <div className="table-responsive">
                <table className="table align-middle table-hover">
                  <thead className="table-light">
                    <tr>
                      <th scope="col" className="py-3 border-0">Job Title</th>
                      <th scope="col" className="py-3 border-0">Company</th>
                      <th scope="col" className="py-3 border-0">Application Date</th>
                      <th scope="col" className="py-3 border-0 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredApplied.map((app) => {
                      const job = sampleJobs.find((j) => j.id === app.jobId);
                      if (!job) return null;
                      return (
                        <tr key={app.id}>
                          <td className="py-3 fw-bold text-dark">{job.title}</td>
                          <td className="py-3 text-muted">{job.company}</td>
                          <td className="py-3 text-muted">{app.appliedDate}</td>
                          <td className="py-3 text-center">{getStatusBadge(app.status)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* SAVED JOBS TAB */}
        {activeTab === "saved" && (
          <div className="card border-0 shadow-sm rounded-12 p-4 bg-white">
            {savedJobs.length === 0 ? (
              <div className="text-center py-5">
                <div className="display-3 text-muted mb-3">
                  <i className="bi bi-bookmark-dash"></i>
                </div>
                <h5 className="fw-bold text-dark">No Saved Jobs</h5>
                <p className="text-muted mb-4">
                  Browse available job openings and save them here for easy access later.
                </p>
                <Link to="/jobs" className="btn btn-primary-custom px-4">
                  Find Jobs to Save
                </Link>
              </div>
            ) : (
              <div className="row g-4">
                {savedJobs.map((job) => {
                  const isAlreadyApplied = appliedJobs.some((app) => app.jobId === job.id);
                  return (
                    <div key={job.id} className="col-12 col-md-6">
                      <div className="card h-100 border p-3.5 rounded-12 shadow-xs position-relative">
                        {/* Remove button */}
                        <button
                          onClick={() => onRemoveSave(job.id)}
                          className="btn btn-outline-danger btn-sm border-0 position-absolute end-0 top-0 mt-3 me-3"
                          title="Remove from Saved"
                        >
                          <i className="bi bi-trash-fill fs-5"></i>
                        </button>

                        <div className="d-flex align-items-center mb-3">
                          <div className={`company-logo ${job.logoBg} me-3`}>
                            {job.logoText}
                          </div>
                          <div>
                            <h6 className="fw-bold mb-1 text-dark">{job.title}</h6>
                            <p className="text-muted mb-0 fs-7.5">{job.company}</p>
                          </div>
                        </div>

                        <div className="d-flex flex-wrap gap-2 mb-3">
                          <span className="badge bg-light text-muted border fs-8">
                            <i className="bi bi-geo-alt"></i> {job.location}
                          </span>
                          <span className="badge bg-light text-muted border fs-8">
                            <i className="bi bi-cash"></i> {job.salaryText}
                          </span>
                          <span className="badge bg-light text-muted border fs-8">
                            <i className="bi bi-briefcase"></i> {job.type}
                          </span>
                        </div>

                        <div className="d-flex justify-content-between align-items-center border-top pt-3 mt-auto">
                          <span className="fs-8 text-muted">Posted {job.postedDate}</span>
                          {isAlreadyApplied ? (
                            <button className="btn btn-success btn-sm px-3" disabled>
                              <i className="bi bi-check-circle-fill"></i> Applied
                            </button>
                          ) : (
                            <button
                              onClick={() => onApply(job)}
                              className="btn btn-primary-custom btn-sm px-3"
                            >
                              Apply Now
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
