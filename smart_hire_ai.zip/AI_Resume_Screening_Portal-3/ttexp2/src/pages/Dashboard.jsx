import React from "react";
import { Link } from "react-router-dom";
import DashboardCard from "../components/DashboardCard";
import JobCard from "../components/JobCard";
import { sampleJobs } from "../data/jobs";

export default function Dashboard({ user, appliedJobs, savedJobIds, onApply, onSave }) {
  // 1. Calculate Profile Completion
  const calculateCompletion = () => {
    if (!user) return 0;
    let score = 0;
    if (user.name) score += 15;
    if (user.email) score += 15;
    if (user.phone) score += 15;
    if (user.location) score += 15;
    if (user.skills && user.skills.length > 0) score += 15;
    if (user.education) score += 10;
    if (user.experience) score += 10;
    if (user.summary || user.resumeTitle) score += 5;
    return score;
  };

  const profileCompletion = calculateCompletion();

  // 2. Count statistics
  const totalJobsAvailable = sampleJobs.length;
  const totalApplied = appliedJobs.length;
  const totalShortlisted = appliedJobs.filter((app) => app.status === "Shortlisted").length;

  // 3. Recommended Jobs: Jobs that match any user skills, or just recent ones if no match
  const recommendedJobs = sampleJobs.filter((job) => {
    if (!user.skills || user.skills.length === 0) return true;
    return job.skills.some((skill) =>
      user.skills.some((uSkill) => uSkill.toLowerCase().includes(skill.toLowerCase()))
    );
  }).slice(0, 3); // Get top 3 recommendations

  // Fallback to first 3 jobs if no matching skill
  const displayRecommendations = recommendedJobs.length > 0 ? recommendedJobs : sampleJobs.slice(0, 3);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  const appliedJobIds = appliedJobs.map((app) => app.jobId);

  return (
    <div className="container py-4">
      {/* Welcome Banner */}
      <div className="bg-white border rounded-12 p-4 p-md-5 mb-4 shadow-sm position-relative overflow-hidden">
        <div className="row align-items-center">
          <div className="col-lg-8">
            <h2 className="fw-bold mb-2 text-dark">
              {getGreeting()}, {user.name}! 👋
            </h2>
            <p className="text-muted mb-4 fs-5" style={{ maxWidth: "600px" }}>
              Welcome to your HireSphere dashboard. You have {totalApplied} active applications. 
              Explore tailored job recommendations below based on your profile skills.
            </p>
            <div className="d-flex gap-2">
              <Link to="/jobs" className="btn btn-primary-custom px-4 py-2">
                <i className="bi bi-briefcase me-1"></i> Browse All Jobs
              </Link>
              <Link to="/profile" className="btn btn-outline-primary-custom px-4 py-2">
                <i className="bi bi-pencil me-1"></i> Edit Profile
              </Link>
            </div>
          </div>
          <div className="col-lg-4 d-none d-lg-block text-end">
            <div className="display-1 text-primary-subtle opacity-50 pe-4">
              <i className="bi bi-person-workspace" style={{ fontSize: "7.5rem" }}></i>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards Grid */}
      <div className="row g-4 mb-5">
        <div className="col-12 col-sm-6 col-lg-3">
          <DashboardCard
            title="Available Jobs"
            value={totalJobsAvailable}
            icon="bi-search"
            textClass="text-primary"
            iconBgClass="bg-primary-subtle"
          />
        </div>
        <div className="col-12 col-sm-6 col-lg-3">
          <DashboardCard
            title="Applied Jobs"
            value={totalApplied}
            icon="bi-file-earmark-check"
            textClass="text-success"
            iconBgClass="bg-success-subtle"
          />
        </div>
        <div className="col-12 col-sm-6 col-lg-3">
          <DashboardCard
            title="Shortlisted"
            value={totalShortlisted}
            icon="bi-award"
            textClass="text-warning"
            iconBgClass="bg-warning-subtle"
          />
        </div>
        <div className="col-12 col-sm-6 col-lg-3">
          <div className="card stat-card h-100">
            <div className="card-body p-4">
              <div className="d-flex align-items-center mb-3">
                <div className="stat-icon bg-info-subtle text-info me-3">
                  <i className="bi bi-percent"></i>
                </div>
                <div>
                  <h6 className="card-subtitle mb-1 text-muted text-uppercase font-monospace fs-7 tracking-wider">
                    Profile Complete
                  </h6>
                  <h3 className="card-title mb-0 fw-bold">{profileCompletion}%</h3>
                </div>
              </div>
              <div className="progress progress-bar-custom" style={{ height: "6px" }}>
                <div
                  className="progress-bar bg-info"
                  role="progressbar"
                  style={{ width: `${profileCompletion}%` }}
                  aria-valuenow={profileCompletion}
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="row">
        {/* Recommended Jobs */}
        <div className="col-12 col-lg-8 mb-4">
          <div className="d-flex align-items-center justify-content-between mb-3">
            <h4 className="fw-bold text-dark mb-0">Recommended for You</h4>
            <Link to="/jobs" className="text-primary text-decoration-none fw-semibold">
              See All <i className="bi bi-arrow-right"></i>
            </Link>
          </div>

          <div className="row g-4">
            {displayRecommendations.map((job) => (
              <div key={job.id} className="col-12">
                <JobCard
                  job={job}
                  isApplied={appliedJobIds.includes(job.id)}
                  isSaved={savedJobIds.includes(job.id)}
                  onApply={onApply}
                  onSave={onSave}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Quick Tips / Sidebar */}
        <div className="col-12 col-lg-4 mb-4">
          <div className="card border-0 shadow-sm rounded-12 p-4 bg-white mb-4">
            <h5 className="fw-bold text-dark mb-3">
              <i className="bi bi-lightning-charge text-warning me-2"></i>Job Search Tips
            </h5>
            <div className="d-flex flex-column gap-3 fs-7.5 text-muted">
              <div className="d-flex">
                <span className="text-primary me-2">●</span>
                <span>Complete your profile to 100% to catch recruiters' attention.</span>
              </div>
              <div className="d-flex">
                <span className="text-primary me-2">●</span>
                <span>Tailor your skills section to match the jobs you are applying for.</span>
              </div>
              <div className="d-flex">
                <span className="text-primary me-2">●</span>
                <span>Check the status of your applications regularly under the "Applications" tab.</span>
              </div>
            </div>
          </div>

          {/* Quick Profile Overview */}
          <div className="card border-0 shadow-sm rounded-12 p-4 bg-white">
            <h5 className="fw-bold text-dark mb-3">Profile Snapshot</h5>
            <div className="mb-3">
              <span className="text-muted d-block fs-8 uppercase font-monospace">Skills Listed:</span>
              <div className="d-flex flex-wrap gap-1 mt-1">
                {user.skills && user.skills.length > 0 ? (
                  user.skills.map((skill, idx) => (
                    <span key={idx} className="badge bg-light text-secondary border">
                      {skill}
                    </span>
                  ))
                ) : (
                  <span className="text-muted fs-7">No skills added yet</span>
                )}
              </div>
            </div>
            <div className="border-top pt-3">
              <p className="mb-1 text-muted fs-7">
                <i className="bi bi-envelope me-2"></i> {user.email}
              </p>
              <p className="mb-0 text-muted fs-7">
                <i className="bi bi-telephone me-2"></i> {user.phone}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
