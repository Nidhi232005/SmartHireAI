import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Login({ onLoginSuccess }) {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    rememberMe: false
  });

  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Check for saved email from "Remember Me"
  useEffect(() => {
    const savedEmail = localStorage.getItem("rememberedEmail");
    if (savedEmail) {
      setFormData((prev) => ({
        ...prev,
        email: savedEmail,
        rememberMe: true
      }));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validate = () => {
    const newErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!formData.email.trim() || !emailRegex.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }

    if (!formData.password) {
      newErrors.password = "Password is required.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);

    if (validate()) {
      // Get all registered users
      const users = JSON.parse(localStorage.getItem("users")) || [];
      const matchedUser = users.find(
        (u) =>
          u.email.toLowerCase() === formData.email.toLowerCase() &&
          u.password === formData.password
      );

      if (matchedUser) {
        // Handle Remember Me
        if (formData.rememberMe) {
          localStorage.setItem("rememberedEmail", formData.email);
        } else {
          localStorage.removeItem("rememberedEmail");
        }

        // Set login success callback (which saves to state and localStorage)
        onLoginSuccess(matchedUser);
        navigate("/dashboard");
      } else {
        setErrors({ general: "Invalid email or password." });
      }
    }
  };

  return (
    <div className="auth-bg">
      <div className="container py-5">
        <div className="row justify-content-center">
          <div className="col-12 col-md-6 col-lg-5">
            <div className="card auth-card shadow-lg">
              {/* Header Gradient */}
              <div className="auth-header-gradient text-center text-white">
                <h2 className="fw-bold mb-1">Welcome Back</h2>
                <p className="mb-0 opacity-80">Log in to manage your applications</p>
              </div>

              {/* Form Body */}
              <div className="card-body p-4 p-md-5">
                {errors.general && (
                  <div className="alert alert-danger d-flex align-items-center" role="alert">
                    <i className="bi bi-exclamation-triangle-fill me-2"></i>
                    <div>{errors.general}</div>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="needs-validation" noValidate>
                  {/* Email */}
                  <div className="mb-3">
                    <label className="form-label fw-semibold">Email Address</label>
                    <div className="input-group">
                      <span className="input-group-text bg-light text-muted border-end-0">
                        <i className="bi bi-envelope"></i>
                      </span>
                      <input
                        type="email"
                        name="email"
                        className={`form-control bg-light border-start-0 ps-0 ${
                          isSubmitted ? (errors.email ? "is-invalid" : "is-valid") : ""
                        }`}
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={handleChange}
                        required
                      />
                      {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                    </div>
                  </div>

                  {/* Password */}
                  <div className="mb-3">
                    <label className="form-label fw-semibold">Password</label>
                    <div className="input-group">
                      <span className="input-group-text bg-light text-muted border-end-0">
                        <i className="bi bi-lock"></i>
                      </span>
                      <input
                        type="password"
                        name="password"
                        className={`form-control bg-light border-start-0 ps-0 ${
                          isSubmitted ? (errors.password ? "is-invalid" : "is-valid") : ""
                        }`}
                        placeholder="******"
                        value={formData.password}
                        onChange={handleChange}
                        required
                      />
                      {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                    </div>
                  </div>

                  {/* Remember Me */}
                  <div className="d-flex align-items-center justify-content-between mb-4">
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        name="rememberMe"
                        id="rememberMe"
                        checked={formData.rememberMe}
                        onChange={handleChange}
                      />
                      <label className="form-check-label text-muted fs-7" htmlFor="rememberMe">
                        Remember Me
                      </label>
                    </div>
                    <a href="#" className="text-primary text-decoration-none fs-7">
                      Forgot Password?
                    </a>
                  </div>

                  {/* Login Button */}
                  <button type="submit" className="btn btn-primary-custom w-100 py-2.5 mb-3">
                    Log In
                  </button>

                  {/* Link to Registration */}
                  <p className="text-center text-muted mb-0">
                    Don't have an account?{" "}
                    <Link to="/register" className="text-primary text-decoration-none fw-bold">
                      Register here
                    </Link>
                  </p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
