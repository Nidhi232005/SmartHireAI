import React, { useState } from "react";
import SearchFilter from "../components/SearchFilter";
import JobList from "../components/JobList";
import { sampleJobs } from "../data/jobs";

export default function Jobs({ appliedJobs, savedJobIds, onApply, onSave }) {
  // State for search and filter selections
  const [filters, setFilters] = useState({
    search: "",
    location: "All Locations",
    type: "All Types",
    experience: "All Experience Levels",
    salary: "All Salaries"
  });

  // Handle updates to specific filters
  const handleFilterChange = (filterName, value) => {
    setFilters((prev) => ({
      ...prev,
      [filterName]: value
    }));
  };

  // Reset filters to defaults
  const handleClearFilters = () => {
    setFilters({
      search: "",
      location: "All Locations",
      type: "All Types",
      experience: "All Experience Levels",
      salary: "All Salaries"
    });
  };

  // Perform multi-filtering logic
  const filteredJobs = sampleJobs.filter((job) => {
    // 1. Search Query Match (Title, Company, or Skills)
    if (filters.search.trim()) {
      const searchLower = filters.search.toLowerCase();
      const titleMatch = job.title.toLowerCase().includes(searchLower);
      const companyMatch = job.company.toLowerCase().includes(searchLower);
      const skillMatch = job.skills.some((s) => s.toLowerCase().includes(searchLower));
      
      if (!titleMatch && !companyMatch && !skillMatch) {
        return false;
      }
    }

    // 2. Location Match
    if (filters.location !== "All Locations") {
      if (job.location !== filters.location) {
        return false;
      }
    }

    // 3. Job Type Match
    if (filters.type !== "All Types") {
      if (job.type !== filters.type) {
        return false;
      }
    }

    // 4. Experience Level Match
    if (filters.experience !== "All Experience Levels") {
      // Map selector values to actual numeric ranges
      if (filters.experience === "Entry Level" && job.experience !== 0) return false;
      if (filters.experience === "1-2 Years" && (job.experience < 1 || job.experience > 2)) return false;
      if (filters.experience === "2-3 Years" && (job.experience < 2 || job.experience > 3)) return false;
      if (filters.experience === "3-4 Years" && (job.experience < 3 || job.experience > 4)) return false;
      if (filters.experience === "5+ Years" && job.experience < 5) return false;
    }

    // 5. Salary Range Match
    if (filters.salary !== "All Salaries") {
      if (filters.salary === "Under $50k" && job.salary >= 50000) return false;
      if (filters.salary === "$50k - $100k" && (job.salary < 50000 || job.salary > 100000)) return false;
      if (filters.salary === "$100k - $130k" && (job.salary < 100000 || job.salary > 130000)) return false;
      if (filters.salary === "$130k+" && job.salary < 130000) return false;
    }

    return true;
  });

  const appliedJobIds = appliedJobs.map((app) => app.jobId);

  return (
    <div className="container py-4">
      {/* Header Info */}
      <div className="row mb-4">
        <div className="col-12 col-md-8">
          <h3 className="fw-bold text-dark mb-1">Explore Job Openings</h3>
          <p className="text-muted">
            Showing {filteredJobs.length} career opportunities matching your preferences
          </p>
        </div>
      </div>

      {/* Filter Section */}
      <SearchFilter
        filters={filters}
        onFilterChange={handleFilterChange}
        onClearFilters={handleClearFilters}
      />

      {/* Grid of Results */}
      <JobList
        jobs={filteredJobs}
        appliedJobIds={appliedJobIds}
        savedJobIds={savedJobIds}
        onApply={onApply}
        onSave={onSave}
      />
    </div>
  );
}
