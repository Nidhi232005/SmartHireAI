import React, { useState } from "react";

export default function Profile({ user, onProfileUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name || "",
    email: user.email || "",
    phone: user.phone || "",
    location: user.location || "",
    gender: user.gender || "",
    education: user.education || "",
    skills: user.skills ? user.skills.join(", ") : "",
    experience: user.experience || "",
    summary: user.summary || "",
    resumeTitle: user.resumeTitle || ""
  });

  const [errors, setErrors] = useState({});
  const [saveSuccess, setSaveSuccess] = useState(false);

  const calculateCompletion = (data) => {
    let score = 0;
    if (data.name) score += 15;
    if (data.email) score += 15;
    if (data.phone) score += 15;
    if (data.location) score += 15;
    
    const skillsArr = data.skills
      ? data.skills.split(",").map((s) => s.trim()).filter((s) => s.length > 0)
      : [];
    if (skillsArr.length > 0) score += 15;
    
    if (data.education) score += 10;
    if (data.experience) score += 10;
    if (data.summary || data.resumeTitle) score += 5;
    return score;
  };

  const currentCompletion = calculateCompletion(formData);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Name cannot be empty.";
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim() || !emailRegex.test(formData.email)) {
      newErrors.email = "Please enter a valid email.";
    }

    const phoneRegex = /^[0-9]{10}$/;
    if (!formData.phone.trim() || !phoneRegex.test(formData.phone)) {
      newErrors.phone = "Phone number must be a 10-digit number.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      const skillsArray = formData.skills
        .split(",")
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

      const updatedUser = {
        ...user,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        location: formData.location,
        gender: formData.gender,
        education: formData.education,
        skills: skillsArray,
        experience: formData.experience,
        summary: formData.summary,
        resumeTitle: formData.resumeTitle
      };

      onProfileUpdate(updatedUser);
      setIsEditing(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  return (
    <div className="container py-4">
      {saveSuccess && (
        <div className="alert alert-success d-flex align-items-center alert-dismissible fade show" role="alert">
          <i className="bi bi-check-circle-fill me-2"></i>
          <div>Profile updated successfully!</div>
          <button type="button" className="btn-close" onClick={() => setSaveSuccess(false)}></button>
        </div>
      )}

      <div className="row g-4">
        {/* Profile Card / Completion Indicator */}
        <div className="col-12 col-lg-4">
          <div className="card border-0 shadow-sm rounded-12 bg-white p-4 text-center mb-4">
            <div className="company-logo bg-primary text-white mx-auto mb-3" style={{ width: "80px", height: "80px", fontSize: "2rem" }}>
              {user.name ? user.name.split(" ").map((n) => n[0]).join("").toUpperCase().substring(0, 2) : "U"}
            </div>
            <h4 className="fw-bold mb-1 text-dark">{user.name}</h4>
            <p className="text-muted fs-7.5 mb-3">
              <i className="bi bi-geo-alt me-1"></i> {user.location || "Location not set"}
            </p>

            <div className="border-top pt-3 text-start">
              <div className="d-flex justify-content-between align-items-center mb-2">
                <span className="fw-semibold text-muted fs-7.5">Profile Strength</span>
                <span className="badge bg-primary-subtle text-primary fw-bold fs-8">{currentCompletion}%</span>
              </div>
              <div className="progress progress-bar-custom mb-3" style={{ height: "8px" }}>
                <div
                  className="progress-bar bg-primary"
                  role="progressbar"
                  style={{ width: `${currentCompletion}%` }}
                  aria-valuenow={currentCompletion}
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
              <p className="fs-8 text-muted mb-0">
                A stronger profile increases your chances of getting shortlisted by up to 3x!
              </p>
            </div>
          </div>

          <div className="card border-0 shadow-sm rounded-12 bg-white p-4">
            <h5 className="fw-bold mb-3 text-dark">Contact Information</h5>
            <div className="d-flex flex-column gap-3">
              <div className="d-flex align-items-start">
                <i className="bi bi-envelope text-primary me-3 fs-5"></i>
                <div>
                  <span className="d-block text-muted fs-8 uppercase font-monospace">Email</span>
                  <span className="fw-semibold text-dark fs-7.5">{user.email}</span>
                </div>
              </div>
              <div className="d-flex align-items-start">
                <i className="bi bi-telephone text-primary me-3 fs-5"></i>
                <div>
                  <span className="d-block text-muted fs-8 uppercase font-monospace">Phone</span>
                  <span className="fw-semibold text-dark fs-7.5">{user.phone}</span>
                </div>
              </div>
              <div className="d-flex align-items-start">
                <i className="bi bi-gender-ambiguous text-primary me-3 fs-5"></i>
                <div>
                  <span className="d-block text-muted fs-8 uppercase font-monospace">Gender</span>
                  <span className="fw-semibold text-dark fs-7.5">{user.gender || "Not Specified"}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Form Card */}
        <div className="col-12 col-lg-8">
          <div className="card border-0 shadow-sm rounded-12 bg-white p-4">
            <div className="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
              <h4 className="fw-bold text-dark mb-0">Profile details</h4>
              {!isEditing && (
                <button
                  onClick={() => setIsEditing(true)}
                  className="btn btn-outline-primary-custom btn-sm px-4 d-flex align-items-center"
                >
                  <i className="bi bi-pencil-square me-2"></i> Edit Profile
                </button>
              )}
            </div>

            <form onSubmit={handleSubmit}>
              <div className="row g-3">
                {/* Full Name */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold text-muted">Full Name</label>
                  <input
                    type="text"
                    name="name"
                    className={`form-control bg-light ${errors.name ? "is-invalid" : ""}`}
                    value={formData.name}
                    onChange={handleChange}
                    disabled={!isEditing}
                  />
                  {errors.name && <div className="invalid-feedback">{errors.name}</div>}
                </div>

                {/* Email Address */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold text-muted">Email Address</label>
                  <input
                    type="email"
                    name="email"
                    className={`form-control bg-light ${errors.email ? "is-invalid" : ""}`}
                    value={formData.email}
                    onChange={handleChange}
                    disabled={!isEditing}
                  />
                  {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                </div>

                {/* Phone */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold text-muted">Phone Number</label>
                  <input
                    type="tel"
                    name="phone"
                    className={`form-control bg-light ${errors.phone ? "is-invalid" : ""}`}
                    value={formData.phone}
                    onChange={handleChange}
                    disabled={!isEditing}
                  />
                  {errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
                </div>

                {/* Location */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold text-muted">Location</label>
                  <input
                    type="text"
                    name="location"
                    className="form-control bg-light"
                    value={formData.location}
                    onChange={handleChange}
                    disabled={!isEditing}
                    placeholder="City, Country"
                  />
                </div>

                {/* Education */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold text-muted">Education Degree</label>
                  <input
                    type="text"
                    name="education"
                    className="form-control bg-light"
                    value={formData.education}
                    onChange={handleChange}
                    disabled={!isEditing}
                    placeholder="e.g. Master of Computer Applications (MCA)"
                  />
                </div>

                {/* Experience */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold text-muted">Professional Experience (Years)</label>
                  <input
                    type="text"
                    name="experience"
                    className="form-control bg-light"
                    value={formData.experience}
                    onChange={handleChange}
                    disabled={!isEditing}
                    placeholder="e.g. 2 Years"
                  />
                </div>

                {/* Skills */}
                <div className="col-12">
                  <label className="form-label fw-semibold text-muted">Technical Skills</label>
                  <input
                    type="text"
                    name="skills"
                    className="form-control bg-light"
                    value={formData.skills}
                    onChange={handleChange}
                    disabled={!isEditing}
                    placeholder="React, JavaScript, HTML, CSS (comma separated)"
                  />
                </div>

                {/* Resume Title */}
                <div className="col-12">
                  <label className="form-label fw-semibold text-muted">Resume Title / Link</label>
                  <input
                    type="text"
                    name="resumeTitle"
                    className="form-control bg-light"
                    value={formData.resumeTitle}
                    onChange={handleChange}
                    disabled={!isEditing}
                    placeholder="e.g. John_Doe_Resume_MCA.pdf (or link to resume)"
                  />
                </div>

                {/* Short Bio / Summary */}
                <div className="col-12">
                  <label className="form-label fw-semibold text-muted">Professional Summary</label>
                  <textarea
                    name="summary"
                    className="form-control bg-light"
                    rows="4"
                    value={formData.summary}
                    onChange={handleChange}
                    disabled={!isEditing}
                    placeholder="Briefly describe your career objectives, skills, and background..."
                  ></textarea>
                </div>
              </div>

              {isEditing && (
                <div className="d-flex gap-2 justify-content-end mt-4 pt-3 border-top">
                  <button
                    type="button"
                    onClick={() => {
                      setFormData({
                        name: user.name || "",
                        email: user.email || "",
                        phone: user.phone || "",
                        location: user.location || "",
                        gender: user.gender || "",
                        education: user.education || "",
                        skills: user.skills ? user.skills.join(", ") : "",
                        experience: user.experience || "",
                        summary: user.summary || "",
                        resumeTitle: user.resumeTitle || ""
                      });
                      setIsEditing(false);
                      setErrors({});
                    }}
                    className="btn btn-outline-secondary px-4"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary-custom px-4">
                    Save Changes
                  </button>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
