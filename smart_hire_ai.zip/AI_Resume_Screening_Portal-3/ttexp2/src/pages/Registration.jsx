import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Registration() {
  const navigate = useNavigate();

  // State values
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    gender: "",
    location: "",
    skills: "",
    termsAccepted: false
  });

  // State errors
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
    // Clear validation error when typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim() || formData.name.length < 3) {
      newErrors.name = "Full Name must be at least 3 characters long.";
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim() || !emailRegex.test(formData.email)) {
      newErrors.email = "Please provide a valid email address.";
    }

    const phoneRegex = /^[0-9]{10}$/;
    if (!formData.phone.trim() || !phoneRegex.test(formData.phone)) {
      newErrors.phone = "Phone number must be a 10-digit number.";
    }

    if (!formData.password || formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters long.";
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
    }

    if (!formData.gender) {
      newErrors.gender = "Please select your gender.";
    }

    if (!formData.location.trim()) {
      newErrors.location = "Please enter your location.";
    }

    if (!formData.skills.trim()) {
      newErrors.skills = "Please list at least one skill.";
    }

    if (!formData.termsAccepted) {
      newErrors.termsAccepted = "You must accept the terms and conditions.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);

    if (validate()) {
      // Fetch existing users from localStorage
      const existingUsers = JSON.parse(localStorage.getItem("users")) || [];

      // Check if user already exists
      const userExists = existingUsers.some((u) => u.email.toLowerCase() === formData.email.toLowerCase());
      if (userExists) {
        setErrors({ email: "Email already registered." });
        return;
      }

      // Add new user (split skills into array)
      const formattedSkills = formData.skills
        .split(",")
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

      const newUser = {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
        gender: formData.gender,
        location: formData.location,
        skills: formattedSkills,
        experience: "",
        education: "",
        summary: "",
        resumeTitle: ""
      };

      existingUsers.push(newUser);
      localStorage.setItem("users", JSON.stringify(existingUsers));

      alert("Registration successful! You can now log in.");
      navigate("/login");
    }
  };

  return (
    <div className="auth-bg">
      <div className="container py-5">
        <div className="row justify-content-center">
          <div className="col-12 col-md-8 col-lg-6">
            <div className="card auth-card shadow-lg">
              {/* Header Gradient */}
              <div className="auth-header-gradient text-center text-white">
                <h2 className="fw-bold mb-1">Join HireSphere</h2>
                <p className="mb-0 opacity-80">Build your profile and land your dream job</p>
              </div>

              {/* Form Body */}
              <div className="card-body p-4 p-md-5">
                <form onSubmit={handleSubmit} className="needs-validation" noValidate>
                  {/* Full Name */}
                  <div className="mb-3">
                    <label className="form-label fw-semibold">Full Name</label>
                    <div className="input-group">
                      <span className="input-group-text bg-light text-muted border-end-0">
                        <i className="bi bi-person"></i>
                      </span>
                      <input
                        type="text"
                        name="name"
                        className={`form-control bg-light border-start-0 ps-0 ${
                          isSubmitted ? (errors.name ? "is-invalid" : "is-valid") : ""
                        }`}
                        placeholder="John Doe"
                        value={formData.name}
                        onChange={handleChange}
                        required
                      />
                      {errors.name && <div className="invalid-feedback">{errors.name}</div>}
                    </div>
                  </div>

                  {/* Email & Phone Row */}
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Email Address</label>
                      <div className="input-group">
                        <span className="input-group-text bg-light text-muted border-end-0">
                          <i className="bi bi-envelope"></i>
                        </span>
                        <input
                          type="email"
                          name="email"
                          className={`form-control bg-light border-start-0 ps-0 ${
                            isSubmitted ? (errors.email ? "is-invalid" : "is-valid") : ""
                          }`}
                          placeholder="john@example.com"
                          value={formData.email}
                          onChange={handleChange}
                          required
                        />
                        {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                      </div>
                    </div>

                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Phone Number</label>
                      <div className="input-group">
                        <span className="input-group-text bg-light text-muted border-end-0">
                          <i className="bi bi-telephone"></i>
                        </span>
                        <input
                          type="tel"
                          name="phone"
                          className={`form-control bg-light border-start-0 ps-0 ${
                            isSubmitted ? (errors.phone ? "is-invalid" : "is-valid") : ""
                          }`}
                          placeholder="9876543210"
                          value={formData.phone}
                          onChange={handleChange}
                          required
                        />
                        {errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
                      </div>
                    </div>
                  </div>

                  {/* Password & Confirm Row */}
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Password</label>
                      <div className="input-group">
                        <span className="input-group-text bg-light text-muted border-end-0">
                          <i className="bi bi-lock"></i>
                        </span>
                        <input
                          type="password"
                          name="password"
                          className={`form-control bg-light border-start-0 ps-0 ${
                            isSubmitted ? (errors.password ? "is-invalid" : "is-valid") : ""
                          }`}
                          placeholder="******"
                          value={formData.password}
                          onChange={handleChange}
                          required
                        />
                        {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                      </div>
                    </div>

                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Confirm Password</label>
                      <div className="input-group">
                        <span className="input-group-text bg-light text-muted border-end-0">
                          <i className="bi bi-lock-fill"></i>
                        </span>
                        <input
                          type="password"
                          name="confirmPassword"
                          className={`form-control bg-light border-start-0 ps-0 ${
                            isSubmitted ? (errors.confirmPassword ? "is-invalid" : "is-valid") : ""
                          }`}
                          placeholder="******"
                          value={formData.confirmPassword}
                          onChange={handleChange}
                          required
                        />
                        {errors.confirmPassword && (
                          <div className="invalid-feedback">{errors.confirmPassword}</div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Gender & Location Row */}
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Gender</label>
                      <select
                        name="gender"
                        className={`form-select bg-light ${
                          isSubmitted ? (errors.gender ? "is-invalid" : "is-valid") : ""
                        }`}
                        value={formData.gender}
                        onChange={handleChange}
                        required
                      >
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                      </select>
                      {errors.gender && <div className="invalid-feedback">{errors.gender}</div>}
                    </div>

                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Location</label>
                      <div className="input-group">
                        <span className="input-group-text bg-light text-muted border-end-0">
                          <i className="bi bi-geo-alt"></i>
                        </span>
                        <input
                          type="text"
                          name="location"
                          className={`form-control bg-light border-start-0 ps-0 ${
                            isSubmitted ? (errors.location ? "is-invalid" : "is-valid") : ""
                          }`}
                          placeholder="e.g. San Francisco, CA"
                          value={formData.location}
                          onChange={handleChange}
                          required
                        />
                        {errors.location && <div className="invalid-feedback">{errors.location}</div>}
                      </div>
                    </div>
                  </div>

                  {/* Skills */}
                  <div className="mb-3">
                    <label className="form-label fw-semibold">Skills</label>
                    <div className="input-group">
                      <span className="input-group-text bg-light text-muted border-end-0">
                        <i className="bi bi-wrench"></i>
                      </span>
                      <input
                        type="text"
                        name="skills"
                        className={`form-control bg-light border-start-0 ps-0 ${
                          isSubmitted ? (errors.skills ? "is-invalid" : "is-valid") : ""
                        }`}
                        placeholder="React, JavaScript, HTML, CSS (comma separated)"
                        value={formData.skills}
                        onChange={handleChange}
                        required
                      />
                      {errors.skills && <div className="invalid-feedback">{errors.skills}</div>}
                    </div>
                  </div>

                  {/* Terms & Conditions */}
                  <div className="mb-4">
                    <div className="form-check">
                      <input
                        className={`form-check-input ${
                          isSubmitted ? (errors.termsAccepted ? "is-invalid" : "is-valid") : ""
                        }`}
                        type="checkbox"
                        name="termsAccepted"
                        id="termsAccepted"
                        checked={formData.termsAccepted}
                        onChange={handleChange}
                        required
                      />
                      <label className="form-check-label text-muted fs-7" htmlFor="termsAccepted">
                        I agree to the <a href="#" className="text-decoration-none text-primary">Terms & Conditions</a>
                      </label>
                      {errors.termsAccepted && (
                        <div className="invalid-feedback">{errors.termsAccepted}</div>
                      )}
                    </div>
                  </div>

                  {/* Register Button */}
                  <button type="submit" className="btn btn-primary-custom w-100 py-2.5 mb-3">
                    Register Account
                  </button>

                  {/* Link to Login */}
                  <p className="text-center text-muted mb-0">
                    Already have an account?{" "}
                    <Link to="/login" className="text-primary text-decoration-none fw-bold">
                      Login here
                    </Link>
                  </p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
