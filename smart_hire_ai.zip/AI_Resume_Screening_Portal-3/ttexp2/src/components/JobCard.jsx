import React from "react";

export default function JobCard({ job, isApplied, isSaved, onApply, onSave }) {
  const {
    id,
    title,
    company,
    location,
    type,
    salaryText,
    experienceText,
    postedDate,
    skills,
    logoBg,
    logoText,
    description
  } = job;

  return (
    <div className="card job-card h-100 border shadow-sm">
      <div className="card-body p-4 d-flex flex-column">
        {/* Top Section: Logo & Meta Info */}
        <div className="d-flex align-items-start justify-content-between mb-3">
          <div className="d-flex align-items-center">
            <div className={`company-logo ${logoBg} me-3`}>
              {logoText}
            </div>
            <div>
              <h5 className="card-title fw-bold mb-1 text-dark">{title}</h5>
              <p className="card-subtitle text-muted mb-0">{company}</p>
            </div>
          </div>
          {/* Save Button */}
          <button
            onClick={() => onSave(id)}
            className={`btn btn-light rounded-circle shadow-sm border-0`}
            style={{ width: "38px", height: "38px", padding: 0 }}
            title={isSaved ? "Unsave Job" : "Save Job"}
          >
            <i className={`bi ${isSaved ? "bi-bookmark-fill text-primary" : "bi-bookmark"}`}></i>
          </button>
        </div>

        {/* Badges Info */}
        <div className="d-flex flex-wrap gap-2 mb-3">
          <span className="badge bg-light text-primary border border-primary-subtle badge-custom">
            <i className="bi bi-geo-alt me-1"></i> {location}
          </span>
          <span className="badge bg-light text-success border border-success-subtle badge-custom">
            <i className="bi bi-briefcase me-1"></i> {type}
          </span>
          <span className="badge bg-light text-warning text-dark border border-warning-subtle badge-custom">
            <i className="bi bi-mortarboard me-1"></i> {experienceText}
          </span>
          <span className="badge bg-light text-info text-dark border border-info-subtle badge-custom">
            <i className="bi bi-cash me-1"></i> {salaryText}
          </span>
        </div>

        {/* Short Description */}
        <p className="card-text text-muted mb-4 flex-grow-1" style={{ fontSize: "0.925rem", lineHeight: "1.5" }}>
          {description}
        </p>

        {/* Skills Section */}
        <div className="mb-4">
          <span className="d-block text-uppercase font-monospace text-muted fs-8 mb-2">Skills Required:</span>
          <div className="d-flex flex-wrap gap-1">
            {skills.map((skill, index) => (
              <span key={index} className="badge bg-light text-secondary border rounded-pill px-2 py-1">
                {skill}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom Section: Date & Apply Button */}
        <div className="d-flex align-items-center justify-content-between pt-3 border-top mt-auto">
          <small className="text-muted">
            <i className="bi bi-clock me-1"></i> {postedDate}
          </small>
          {isApplied ? (
            <button className="btn btn-success d-flex align-items-center px-4" disabled>
              <i className="bi bi-check-circle-fill me-2"></i> Applied
            </button>
          ) : (
            <button
              onClick={() => onApply(job)}
              className="btn btn-primary-custom px-4"
            >
              Apply Now
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
