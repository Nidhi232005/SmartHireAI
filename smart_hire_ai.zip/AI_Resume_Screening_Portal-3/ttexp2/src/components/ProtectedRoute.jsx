import React from "react";
import { Navigate } from "react-router-dom";

/**
 * ProtectedRoute component
 * Checks if a user is logged in (either in context or localStorage)
 * If not, redirects to the login page.
 */
export default function ProtectedRoute({ children }) {
  const currentUser = localStorage.getItem("currentUser");

  if (!currentUser) {
    // Redirect to login if user is not authenticated
    return <Navigate to="/login" replace />;
  }

  return children;
}
