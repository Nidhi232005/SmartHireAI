import React from "react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-white border-top py-4 mt-auto">
      <div className="container">
        <div className="row align-items-center justify-content-between text-center text-md-start">
          <div className="col-md-6 mb-3 mb-md-0">
            <span className="fw-bold text-primary fs-5">
              <i className="bi bi-briefcase-fill me-1"></i> HireSphere
            </span>
            <span className="text-muted ms-2">
              © {new Date().getFullYear()} - Modern Recruitment Portal. All rights reserved.
            </span>
          </div>
          <div className="col-md-6 text-center text-md-end">
            <ul className="list-inline mb-0">
              <li className="list-inline-item">
                <a href="#" className="text-muted text-decoration-none px-2">Privacy Policy</a>
              </li>
              <li className="list-inline-item">
                <a href="#" className="text-muted text-decoration-none px-2">Terms of Service</a>
              </li>
              <li className="list-inline-item">
                <a href="#" className="text-muted text-decoration-none px-2">Help Center</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}
