import React from "react";

export default function DashboardCard({ title, value, icon, bgClass, textClass, iconBgClass }) {
  return (
    <div className="card stat-card h-100">
      <div className="card-body p-4 d-flex align-items-center">
        <div className={`stat-icon ${iconBgClass} ${textClass} me-3`}>
          <i className={`bi ${icon}`}></i>
        </div>
        <div>
          <h6 className="card-subtitle mb-1 text-muted text-uppercase font-monospace fs-7 tracking-wider">
            {title}
          </h6>
          <h3 className="card-title mb-0 fw-bold">{value}</h3>
        </div>
      </div>
    </div>
  );
}
