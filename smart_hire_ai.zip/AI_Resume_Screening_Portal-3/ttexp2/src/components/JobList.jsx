import React from "react";
import JobCard from "./JobCard";

export default function JobList({ jobs, appliedJobIds, savedJobIds, onApply, onSave }) {
  if (jobs.length === 0) {
    return (
      <div className="card text-center py-5 border-0 shadow-sm rounded-12 bg-white">
        <div className="card-body">
          <div className="display-4 text-muted mb-3">
            <i className="bi bi-search-heart"></i>
          </div>
          <h4 className="fw-bold text-dark mb-2">No Matching Jobs Found</h4>
          <p className="text-muted mb-4 max-w-md mx-auto">
            We couldn't find any job listings matching your current search parameters. Try adjusting your search query or resetting filters.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="row g-4">
      {jobs.map((job) => (
        <div key={job.id} className="col-12 col-md-6 col-lg-6">
          <JobCard
            job={job}
            isApplied={appliedJobIds.includes(job.id)}
            isSaved={savedJobIds.includes(job.id)}
            onApply={onApply}
            onSave={onSave}
          />
        </div>
      ))}
    </div>
  );
}
