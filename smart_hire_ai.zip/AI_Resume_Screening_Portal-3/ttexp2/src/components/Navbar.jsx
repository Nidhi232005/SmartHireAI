import React from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";

export default function Navbar({ user, onLogout }) {
  const navigate = useNavigate();

  const handleLogoutClick = (e) => {
    e.preventDefault();
    onLogout();
    navigate("/login");
  };

  // Get user initials for avatar
  const getInitials = (name) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-custom sticky-top py-3">
      <div className="container">
        {/* Brand Logo */}
        <Link className="navbar-brand d-flex align-items-center fw-bold text-primary fs-4" to="/dashboard">
          <i className="bi bi-briefcase-fill me-2"></i>
          <span>HireSphere</span>
        </Link>

        {/* Responsive Toggle Button */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarContent"
          aria-controls="navbarContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Navbar Links */}
        <div className="collapse navbar-collapse" id="navbarContent">
          {user ? (
            <>
              <ul className="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4 gap-2">
                <li className="nav-item">
                  <NavLink className={({ isActive }) => `nav-link nav-link-custom ${isActive ? "active" : ""}`} to="/dashboard">
                    <i className="bi bi-grid-1x2-fill me-1"></i> Dashboard
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className={({ isActive }) => `nav-link nav-link-custom ${isActive ? "active" : ""}`} to="/jobs">
                    <i className="bi bi-search me-1"></i> Browse Jobs
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className={({ isActive }) => `nav-link nav-link-custom ${isActive ? "active" : ""}`} to="/applications">
                    <i className="bi bi-file-earmark-person-fill me-1"></i> Applications
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className={({ isActive }) => `nav-link nav-link-custom ${isActive ? "active" : ""}`} to="/profile">
                    <i className="bi bi-person-fill me-1"></i> Profile
                  </NavLink>
                </li>
              </ul>

              {/* User Dropdown */}
              <div className="d-flex align-items-center">
                <div className="dropdown">
                  <a
                    className="d-flex align-items-center text-decoration-none dropdown-toggle cursor-pointer"
                    href="#"
                    role="button"
                    id="userDropdown"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    <div className="company-logo bg-primary text-white me-2" style={{ width: "38px", height: "38px", fontSize: "0.95rem" }}>
                      {getInitials(user.name)}
                    </div>
                    <span className="d-none d-md-inline text-dark fw-semibold">{user.name}</span>
                  </a>

                  <ul className="dropdown-menu dropdown-menu-end shadow-sm border-0 mt-2" aria-labelledby="userDropdown">
                    <li>
                      <Link className="dropdown-item py-2" to="/profile">
                        <i className="bi bi-person me-2"></i> My Profile
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item py-2" to="/applications">
                        <i className="bi bi-journal-check me-2"></i> Applied Jobs
                      </Link>
                    </li>
                    <li>
                      <hr className="dropdown-divider" />
                    </li>
                    <li>
                      <a className="dropdown-item py-2 text-danger" href="#" onClick={handleLogoutClick}>
                        <i className="bi bi-box-arrow-right me-2"></i> Logout
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </>
          ) : (
            <div className="d-flex ms-auto gap-2">
              <Link className="btn btn-outline-primary-custom px-4" to="/login">
                Login
              </Link>
              <Link className="btn btn-primary-custom px-4" to="/register">
                Register
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
