import React from "react";
import {
  sampleLocations,
  sampleJobTypes,
  sampleExperiences,
  sampleSalaries
} from "../data/jobs";

export default function SearchFilter({
  filters,
  onFilterChange,
  onClearFilters
}) {
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    onFilterChange(name, value);
  };

  return (
    <div className="card border-0 shadow-sm rounded-12 bg-white p-4 mb-4">
      <h5 className="fw-bold mb-3 text-dark">
        <i className="bi bi-funnel-fill text-primary me-2"></i>Filter Opportunities
      </h5>
      <div className="row g-3">
        {/* Search Input */}
        <div className="col-12 col-md-4">
          <label className="form-label fw-semibold text-muted fs-7">Search Jobs</label>
          <div className="input-group">
            <span className="input-group-text bg-light border-end-0">
              <i className="bi bi-search text-muted"></i>
            </span>
            <input
              type="text"
              name="search"
              className="form-control bg-light border-start-0 ps-0"
              placeholder="Title, Company, or Skill..."
              value={filters.search}
              onChange={handleInputChange}
            />
          </div>
        </div>

        {/* Location Filter */}
        <div className="col-12 col-sm-6 col-md-2">
          <label className="form-label fw-semibold text-muted fs-7">Location</label>
          <select
            name="location"
            className="form-select bg-light"
            value={filters.location}
            onChange={handleInputChange}
          >
            {sampleLocations.map((loc, idx) => (
              <option key={idx} value={loc}>
                {loc}
              </option>
            ))}
          </select>
        </div>

        {/* Job Type Filter */}
        <div className="col-12 col-sm-6 col-md-2">
          <label className="form-label fw-semibold text-muted fs-7">Job Type</label>
          <select
            name="type"
            className="form-select bg-light"
            value={filters.type}
            onChange={handleInputChange}
          >
            {sampleJobTypes.map((t, idx) => (
              <option key={idx} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        {/* Experience Filter */}
        <div className="col-12 col-sm-6 col-md-2">
          <label className="form-label fw-semibold text-muted fs-7">Experience</label>
          <select
            name="experience"
            className="form-select bg-light"
            value={filters.experience}
            onChange={handleInputChange}
          >
            {sampleExperiences.map((exp, idx) => (
              <option key={idx} value={exp}>
                {exp}
              </option>
            ))}
          </select>
        </div>

        {/* Salary Filter */}
        <div className="col-12 col-sm-6 col-md-2">
          <label className="form-label fw-semibold text-muted fs-7">Salary Range</label>
          <select
            name="salary"
            className="form-select bg-light"
            value={filters.salary}
            onChange={handleInputChange}
          >
            {sampleSalaries.map((sal, idx) => (
              <option key={idx} value={sal}>
                {sal}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Clear Filters Button */}
      <div className="d-flex justify-content-end mt-3">
        <button
          onClick={onClearFilters}
          className="btn btn-outline-secondary btn-sm px-3 d-flex align-items-center"
        >
          <i className="bi bi-x-circle me-1"></i> Clear All Filters
        </button>
      </div>
    </div>
  );
}
