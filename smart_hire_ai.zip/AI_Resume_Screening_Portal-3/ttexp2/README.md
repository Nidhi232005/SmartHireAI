# HireSphere - Modern Career & Job Portal

HireSphere is a premium, fully responsive React.js and Bootstrap 5 career portal application. It includes user authentication, dynamic job searching and multi-filtering, dashboard metrics, profile updating, and application status tracking.

All user activities, application records, and profile details are persisted using `localStorage`.

---

## 🚀 Setup & Execution Guide

### Prerequisite
Ensure you have [Node.js](https://nodejs.org/) installed (v16 or higher recommended).

### 1. Installation
Extract the project, open your terminal at the project directory (`ttexp2`), and run:
```bash
npm install
```

### 2. Run Development Server
Start the Vite dev server by running:
```bash
npm run dev
```
Open the provided URL (typically `http://localhost:5173/` or `http://localhost:5174/`) in your browser.

### 🔑 Demo Login Credentials
For quick evaluation without registering, you can log in using this pre-seeded account:
- **Email**: `alex@hiresphere.com`
- **Password**: `password123`

---

## 💡 React & Frontend Architecture Explanation

### 1. Component-Based Architecture
The project follows a clean modular structure to maximize reusability:
- **Reusable UI Components** (`src/components/`):
  - `Navbar` & `Footer` for page layouts.
  - `JobCard` for rendering individual listings with badge statuses and action buttons.
  - `JobList` for handling the grid map layout and empty/no-results placeholders.
  - `SearchFilter` for bundling keywords and multiple select selectors.
  - `DashboardCard` for rendering numeric statistics with icons.
- **Routing Pages** (`src/pages/`):
  - `Registration` & `Login` for account operations.
  - `Dashboard`, `Jobs`, `Applications`, and `Profile` for core client layouts.

### 2. State Management (`useState`)
- **Global State (`src/App.jsx`)**: Holds the `currentUser`, `appliedJobs`, and `savedJobIds`. This serves as the single source of truth.
- **Local Form State**: Used in `Login`, `Registration`, and `Profile` to control form inputs (`formData`) and handle client-side validations (`errors`).
- **Filter State**: Managed in `Jobs.jsx` to control and update search keyword queries and filters before filtering the job list array.

### 3. Lifecycle & Side Effects (`useEffect`)
- On mounting (`App.jsx`), a `useEffect` seeds the default user data and loads saved session profiles from `localStorage`.
- Additional `useEffect` blocks trigger state syncs to `localStorage` automatically whenever the user updates their profile, applies to a job, or toggles bookmarks.

### 4. Client-Side Routing (`react-router-dom`)
- Configured using `HashRouter` to prevent 404 errors when reloading routes in static hosts or double-clicking local builds.
- Wraps private paths in `ProtectedRoute` to redirect unauthorized navigation requests back to `/login`.

### 5. Local Storage Integration
- Form validations write registered users into a local `users` array in storage.
- Logged-in tokens are saved as `currentUser`, ensuring that refreshing or closing the browser keeps the user logged in.

---

## 🎓 Academic Viva Questions & Answers (Study Guide)

#### Q1: Why did you use `HashRouter` instead of `BrowserRouter`?
**Ans**: `HashRouter` uses the URL hash (the portion after `#`) to keep the UI in sync with the URL. It is preferred for demonstrations because it does not require server fallback configuration, preventing route-related 404 errors when reloading the page on local dev servers or static web hosts.

#### Q2: How does the filtering logic work?
**Ans**: We use a declarative Javascript `.filter()` chain on the master `sampleJobs` array in `Jobs.jsx`. The function checks each job against the search string (matching title, company, or skills) and selected dropdown filters (location, type, experience, and salary range). Only jobs that satisfy all active conditions are returned and passed to `JobList`.

#### Q3: How is Profile Completion calculated?
**Ans**: The completion percentage is calculated dynamically by checking the truthiness of user profile attributes in `Profile.jsx` / `Dashboard.jsx`. Each complete field adds a specific weight (e.g., Name/Email/Phone/Location/Skills each add 15%, Education/Experience add 10%, and summary/resume adds 5%) summing up to a total of 100%.

#### Q4: What is a Protected Route and how did you implement it?
**Ans**: A protected route is a navigation guard that restricts access to authenticated users. In `ProtectedRoute.jsx`, the component checks if `currentUser` exists in `localStorage`. If not, it redirects the request to `/login` using the React Router `<Navigate>` component, blocking access to pages like the Dashboard or Applications.

#### Q5: How is form validation handled?
**Ans**: Form submission triggers a validation handler. We verify inputs against regular expressions (such as email structure and 10-digit phone patterns), check password matching, and confirm required selections. If errors exist, they are written to the local `errors` state which attaches Bootstrap's `.is-invalid` class to show contextual alert feedback.
