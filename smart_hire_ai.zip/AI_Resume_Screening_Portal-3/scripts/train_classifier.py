"""
scripts/train_classifier.py
-----------------------------
Generates a synthetic-but-realistic labeled dataset of candidate feature
vectors, trains a Logistic Regression classifier to predict hiring
"fit" (1 = good fit / would be shortlisted, 0 = not a fit), evaluates it
on a held-out test split, and saves both the trained model and its
evaluation metrics to the models/ directory.

Why synthetic data? This is an academic minor project with no access to
a real company's historical hiring outcomes. The synthetic generator
encodes a plausible, documented rule of thumb (candidates with high
skill overlap AND high textual similarity AND relevant experience are
more likely to be hired) plus random noise, so the classifier has a
genuine, non-trivial pattern to learn -- and its accuracy can be
honestly reported rather than trivially perfect or meaningless.

Run with:
    python scripts/train_classifier.py
"""

import os
import sys
import json
import random

import numpy as np
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score,
)

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai.classifier import MODEL_DIR, MODEL_PATH, METRICS_PATH, FEATURE_NAMES

RANDOM_SEED = 42
N_SAMPLES = 1200


def generate_synthetic_dataset(n_samples=N_SAMPLES, seed=RANDOM_SEED):
    """
    Simulates candidate feature vectors and a binary 'good_fit' label.
    The underlying (hidden) rule blends skill match, textual similarity,
    experience and education, then adds Gaussian noise and a random
    labeling-error rate to mimic real-world imperfect ground truth.
    """
    rng = np.random.default_rng(seed)

    cosine_score = rng.uniform(0, 100, n_samples)
    semantic_score = np.clip(cosine_score + rng.normal(0, 12, n_samples), 0, 100)
    skill_match_pct = rng.uniform(0, 100, n_samples)
    experience_years = np.clip(rng.exponential(2.5, n_samples), 0, 15)
    education_match = rng.integers(0, 2, n_samples)

    # Hidden scoring rule used only to generate plausible ground-truth labels
    latent_score = (
        0.35 * cosine_score +
        0.15 * semantic_score +
        0.35 * skill_match_pct +
        4.0 * np.clip(experience_years, 0, 6) +
        8.0 * education_match
    )
    latent_score += rng.normal(0, 10, n_samples)  # noise / real-world unpredictability

    threshold = np.percentile(latent_score, 55)  # roughly balanced classes
    good_fit = (latent_score >= threshold).astype(int)

    # Introduce a small amount of label noise (imperfect human hiring decisions)
    flip_mask = rng.random(n_samples) < 0.05
    good_fit[flip_mask] = 1 - good_fit[flip_mask]

    X = np.column_stack([cosine_score, semantic_score, skill_match_pct, experience_years, education_match])
    y = good_fit
    return X, y


def train_and_evaluate():
    os.makedirs(MODEL_DIR, exist_ok=True)

    X, y = generate_synthetic_dataset()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=RANDOM_SEED, stratify=y
    )

    model = LogisticRegression(max_iter=1000, class_weight="balanced")
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "n_train_samples": int(len(X_train)),
        "n_test_samples": int(len(X_test)),
        "accuracy": round(float(accuracy_score(y_test, y_pred)), 4),
        "precision": round(float(precision_score(y_test, y_pred)), 4),
        "recall": round(float(recall_score(y_test, y_pred)), 4),
        "f1_score": round(float(f1_score(y_test, y_pred)), 4),
        "roc_auc": round(float(roc_auc_score(y_test, y_proba)), 4),
        "confusion_matrix": confusion_matrix(y_test, y_pred).tolist(),
        "confusion_matrix_labels": ["Not a Fit (0)", "Good Fit (1)"],
        "feature_names": FEATURE_NAMES,
        "feature_coefficients": {
            name: round(float(coef), 4)
            for name, coef in zip(FEATURE_NAMES, model.coef_[0])
        },
        "classification_report": classification_report(y_test, y_pred, output_dict=True),
    }

    joblib.dump(model, MODEL_PATH)
    with open(METRICS_PATH, "w") as f:
        json.dump(metrics, f, indent=2)

    print("=" * 60)
    print("Resume-Fit Classifier — Training Complete")
    print("=" * 60)
    print(f"Train samples : {metrics['n_train_samples']}")
    print(f"Test samples  : {metrics['n_test_samples']}")
    print(f"Accuracy      : {metrics['accuracy']}")
    print(f"Precision     : {metrics['precision']}")
    print(f"Recall        : {metrics['recall']}")
    print(f"F1 Score      : {metrics['f1_score']}")
    print(f"ROC AUC       : {metrics['roc_auc']}")
    print(f"Confusion Matrix (rows=actual, cols=predicted):\n{np.array(metrics['confusion_matrix'])}")
    print("-" * 60)
    print(f"Model saved to   : {MODEL_PATH}")
    print(f"Metrics saved to : {METRICS_PATH}")
    print("=" * 60)


if __name__ == "__main__":
    random.seed(RANDOM_SEED)
    train_and_evaluate()
