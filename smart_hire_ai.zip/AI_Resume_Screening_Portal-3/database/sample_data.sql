-- =====================================================================
--  Sample / demo data for the AI Resume Screening & Recruitment Portal
--  Run AFTER schema.sql:  mysql -u root -p resume_screening_db < database/sample_data.sql
--  Demo login -> email: hr@demo.com | password: Demo@123
-- =====================================================================

USE resume_screening_db;

INSERT INTO users (full_name, email, password_hash, company_name, role)
VALUES (
    'Priya Sharma',
    'hr@demo.com',
    'pbkdf2:sha256:600000$8pYb0rq6qzX8YQaT$e6ef157e2f2f6b3f8a2f6b0b1c9c0e4f6a1e2c3d4b5a6978fcb0a1d2e3f4a5b6',
    'BrightTech Solutions',
    'HR'
);

INSERT INTO jobs (posted_by, job_title, company, location, experience_req, required_skills, education, salary, job_description, status, is_public)
VALUES
(1, 'Python Backend Developer', 'BrightTech Solutions', 'Bengaluru, India', '2-4 years',
 'Python, Flask, Django, REST API, MySQL, Git, Docker',
 'B.Tech/B.E. in Computer Science or related field', '8-14 LPA',
 'We are looking for a skilled Python Backend Developer to design and maintain scalable REST APIs, work with relational databases, and collaborate with the frontend team to deliver robust web applications.',
 'ACTIVE', 1),
(1, 'Machine Learning Engineer', 'BrightTech Solutions', 'Remote', '1-3 years',
 'Python, Scikit-learn, TensorFlow, NLP, Pandas, NumPy, Data Preprocessing',
 'M.Tech/MCA/B.Tech in CS, AI or Data Science', '10-18 LPA',
 'Seeking a Machine Learning Engineer to build and deploy NLP and ML pipelines, including text classification, similarity scoring, and predictive models for our HR-tech product suite.',
 'ACTIVE', 1),
(1, 'Frontend Developer (React)', 'BrightTech Solutions', 'Pune, India', '1-2 years',
 'HTML, CSS, JavaScript, React, Bootstrap, REST API Integration',
 'B.Tech/BCA/MCA', '6-10 LPA',
 'Looking for a Frontend Developer to build responsive, accessible interfaces using React and Bootstrap, integrating with backend REST APIs.',
 'ACTIVE', 1);

INSERT INTO candidates (job_id, full_name, email, phone, education, experience, skills, source, status)
VALUES
(1, 'Rohit Verma', 'rohit.verma@example.com', '9876543210', 'B.Tech Computer Science', '3 years',
 'Python, Flask, MySQL, REST API, Git, Docker', 'HR_UPLOAD', 'SHORTLISTED'),
(1, 'Ananya Iyer', 'ananya.iyer@example.com', '9876501234', 'M.Tech Computer Science', '2 years',
 'Python, Django, PostgreSQL, REST API, AWS', 'HR_UPLOAD', 'PENDING'),
(2, 'Karan Mehta', 'karan.mehta@example.com', '9123456789', 'MCA', '2 years',
 'Python, Scikit-learn, Pandas, NumPy, NLP, TensorFlow', 'PUBLIC_APPLICATION', 'INTERVIEW');

INSERT INTO resume_scores (candidate_id, job_id, cosine_score, semantic_score, match_score, skill_match_pct, matched_skills, missing_skills, rank_position, recommendation, scoring_method)
VALUES
(1, 1, 74.10, 68.50, 78.40, 83.33, 'Python, Flask, MySQL, REST API, Git, Docker', 'Django', 1, 'SHORTLIST', 'RULE_BASED'),
(2, 1, 52.00, 49.20, 55.10, 60.00, 'Python, REST API', 'Flask, MySQL, Git, Docker', 2, 'REVIEW', 'RULE_BASED'),
(3, 2, 79.80, 74.10, 81.25, 85.71, 'Python, Scikit-learn, Pandas, NumPy, NLP', 'TensorFlow', 1, 'SHORTLIST', 'RULE_BASED');

INSERT INTO candidate_status_history (candidate_id, old_status, new_status)
VALUES
(1, 'PENDING', 'SHORTLISTED'),
(3, 'PENDING', 'SHORTLISTED'),
(3, 'SHORTLISTED', 'INTERVIEW');

INSERT INTO interviews (candidate_id, job_id, scheduled_by, scheduled_at, mode, location_or_link, notes, status)
VALUES
(3, 2, 1, DATE_ADD(NOW(), INTERVAL 3 DAY), 'ONLINE', 'https://meet.example.com/karan-mehta', 'First-round technical interview focusing on NLP projects.', 'SCHEDULED');
