-- =====================================================================
--  AI Resume Screening & Recruitment Portal - Database Schema (v2)
--  Run with:  mysql -u root -p < database/schema.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS resume_screening_db;
USE resume_screening_db;

-- ---------------------------------------------------------------------
-- Users (HR / Admin accounts)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id        INT AUTO_INCREMENT PRIMARY KEY,
    full_name      VARCHAR(120)  NOT NULL,
    email          VARCHAR(150)  NOT NULL UNIQUE,
    password_hash  VARCHAR(255)  NOT NULL,
    company_name   VARCHAR(150)  DEFAULT NULL,
    role           ENUM('HR', 'ADMIN') NOT NULL DEFAULT 'HR',
    reset_token    VARCHAR(255)  DEFAULT NULL,
    reset_expires  DATETIME      DEFAULT NULL,
    created_at     TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_email (email)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Jobs
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS jobs (
    job_id           INT AUTO_INCREMENT PRIMARY KEY,
    posted_by        INT NOT NULL,
    job_title        VARCHAR(150) NOT NULL,
    company          VARCHAR(150) NOT NULL,
    location         VARCHAR(120) NOT NULL,
    experience_req   VARCHAR(50)  NOT NULL,
    required_skills  TEXT         NOT NULL,
    education        VARCHAR(150) NOT NULL,
    salary           VARCHAR(80)  DEFAULT NULL,
    job_description  TEXT         NOT NULL,
    status           ENUM('ACTIVE', 'CLOSED') NOT NULL DEFAULT 'ACTIVE',
    is_public        TINYINT(1)   NOT NULL DEFAULT 1,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (posted_by) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_jobs_title (job_title),
    INDEX idx_jobs_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Candidates
-- Status now models a full hiring pipeline (kanban board columns):
-- APPLIED -> PENDING (AI screened) -> SHORTLISTED -> INTERVIEW -> HIRED
--                                                              -> REJECTED
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS candidates (
    candidate_id   INT AUTO_INCREMENT PRIMARY KEY,
    job_id         INT NOT NULL,
    full_name      VARCHAR(150) DEFAULT NULL,
    email          VARCHAR(150) DEFAULT NULL,
    phone          VARCHAR(30)  DEFAULT NULL,
    education      VARCHAR(200) DEFAULT NULL,
    experience     VARCHAR(100) DEFAULT NULL,
    skills         TEXT         DEFAULT NULL,
    source         ENUM('HR_UPLOAD', 'PUBLIC_APPLICATION') NOT NULL DEFAULT 'HR_UPLOAD',
    status         ENUM('APPLIED', 'PENDING', 'SHORTLISTED', 'INTERVIEW', 'HIRED', 'REJECTED')
                   NOT NULL DEFAULT 'PENDING',
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE,
    INDEX idx_candidates_job (job_id),
    INDEX idx_candidates_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Candidate status history (used for time-to-hire / funnel analytics)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS candidate_status_history (
    history_id     INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id   INT NOT NULL,
    old_status     VARCHAR(20) DEFAULT NULL,
    new_status     VARCHAR(20) NOT NULL,
    changed_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES candidates(candidate_id) ON DELETE CASCADE,
    INDEX idx_history_candidate (candidate_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Uploaded resume files (raw storage + extracted text)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS uploaded_resumes (
    resume_id      INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id   INT NOT NULL,
    original_name  VARCHAR(255) NOT NULL,
    stored_path    VARCHAR(500) NOT NULL,
    file_type      VARCHAR(10)  NOT NULL,
    raw_text       LONGTEXT     DEFAULT NULL,
    uploaded_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES candidates(candidate_id) ON DELETE CASCADE,
    INDEX idx_resumes_candidate (candidate_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Resume scores (AI output per candidate per job)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS resume_scores (
    score_id          INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id      INT NOT NULL,
    job_id            INT NOT NULL,
    cosine_score      DECIMAL(5,2) DEFAULT NULL,
    semantic_score    DECIMAL(5,2) DEFAULT NULL,
    match_score       DECIMAL(5,2) NOT NULL,
    skill_match_pct   DECIMAL(5,2) DEFAULT NULL,
    matched_skills    TEXT DEFAULT NULL,
    missing_skills    TEXT DEFAULT NULL,
    rank_position     INT DEFAULT NULL,
    recommendation    ENUM('SHORTLIST', 'REVIEW', 'REJECT') NOT NULL,
    ml_probability    DECIMAL(5,2) DEFAULT NULL,
    scoring_method     ENUM('RULE_BASED', 'ML_CLASSIFIER') NOT NULL DEFAULT 'RULE_BASED',
    scored_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES candidates(candidate_id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE,
    INDEX idx_scores_job (job_id),
    INDEX idx_scores_candidate (candidate_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Interviews
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS interviews (
    interview_id    INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id    INT NOT NULL,
    job_id          INT NOT NULL,
    scheduled_by    INT NOT NULL,
    scheduled_at    DATETIME NOT NULL,
    mode            ENUM('ONLINE', 'IN_PERSON', 'PHONE') NOT NULL DEFAULT 'ONLINE',
    location_or_link VARCHAR(255) DEFAULT NULL,
    notes           TEXT DEFAULT NULL,
    status          ENUM('SCHEDULED', 'COMPLETED', 'CANCELLED') NOT NULL DEFAULT 'SCHEDULED',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES candidates(candidate_id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE,
    FOREIGN KEY (scheduled_by) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_interviews_candidate (candidate_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Reports (saved/exported hiring reports per job)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reports (
    report_id          INT AUTO_INCREMENT PRIMARY KEY,
    job_id             INT NOT NULL,
    generated_by       INT NOT NULL,
    total_applications INT DEFAULT 0,
    avg_match_score    DECIMAL(5,2) DEFAULT 0,
    highest_score      DECIMAL(5,2) DEFAULT 0,
    lowest_score       DECIMAL(5,2) DEFAULT 0,
    top_skills         TEXT DEFAULT NULL,
    missing_skills     TEXT DEFAULT NULL,
    generated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE,
    FOREIGN KEY (generated_by) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_reports_job (job_id)
) ENGINE=InnoDB;
