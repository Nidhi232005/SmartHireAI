"""
ai/semantic_similarity.py
--------------------------
A lightweight "semantic" matching mode that goes beyond raw keyword
overlap without requiring a large pretrained language model download.

It builds a TF-IDF matrix over the job description + all resumes, then
applies Truncated SVD (i.e. Latent Semantic Analysis / LSA) to project
every document into a lower-dimensional "concept" space. Cosine
similarity computed in this reduced space captures relationships between
co-occurring terms (e.g. "Flask" and "REST API" tend to appear together),
so two documents can score as similar even if they don't share many
literal words -- something plain TF-IDF cosine similarity cannot do.

This is intentionally simple and fully explainable (a documented,
decades-old IR technique), which makes it easy to justify in an
academic report while still demonstrating a "semantic" matching mode
distinct from the literal TF-IDF approach in ai/similarity.py.
"""

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics.pairwise import cosine_similarity

from ai.preprocess import clean_text


def compute_semantic_scores(job_description: str, resume_texts: list, n_components: int = 50) -> list:
    """
    Returns a list of LSA-based cosine-similarity scores (0-100 float),
    one per resume, in the same order as resume_texts. Falls back
    gracefully to an all-zero list if there isn't enough text/vocabulary
    to fit a meaningful decomposition (e.g. only one very short resume).
    """
    if not resume_texts:
        return []

    jd_clean = clean_text(job_description)
    resumes_clean = [clean_text(r) for r in resume_texts]
    corpus = [jd_clean] + resumes_clean

    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 1))
    tfidf_matrix = vectorizer.fit_transform(corpus)

    n_features = tfidf_matrix.shape[1]
    n_docs = tfidf_matrix.shape[0]
    safe_components = max(2, min(n_components, n_features - 1, n_docs - 1))

    if n_features < 3 or n_docs < 2 or safe_components < 2:
        return [0.0 for _ in resume_texts]

    svd = TruncatedSVD(n_components=safe_components, random_state=42)
    reduced = svd.fit_transform(tfidf_matrix)

    jd_vector = reduced[0:1]
    resume_vectors = reduced[1:]

    similarities = cosine_similarity(jd_vector, resume_vectors)[0]
    # LSA cosine similarities can occasionally be slightly negative;
    # clip to a valid 0-100 percentage range for display purposes.
    scores = [round(float(max(0.0, min(1.0, sim))) * 100, 2) for sim in similarities]
    return scores
