"""
ai/similarity.py
-----------------
Core lexical matching engine: converts the (cleaned) job description and
each cleaned resume into TF-IDF vectors, then computes cosine similarity
to produce a Match Score (%). Also computes an explicit skill-overlap
score so recruiters can see both "overall text similarity" and
"explicit skill match" side by side.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from ai.preprocess import clean_text


def compute_match_scores(job_description: str, resume_texts: list) -> list:
    """
    Returns a list of TF-IDF cosine-similarity scores (0-100 float), one
    per resume, in the same order as resume_texts.
    """
    if not resume_texts:
        return []

    jd_clean = clean_text(job_description)
    resumes_clean = [clean_text(r) for r in resume_texts]

    corpus = [jd_clean] + resumes_clean
    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
    tfidf_matrix = vectorizer.fit_transform(corpus)

    jd_vector = tfidf_matrix[0:1]
    resume_vectors = tfidf_matrix[1:]

    similarities = cosine_similarity(jd_vector, resume_vectors)[0]
    return [round(float(sim) * 100, 2) for sim in similarities]


def compute_skill_match(required_skills: str, candidate_skills: list) -> dict:
    """
    Returns {"percentage": float, "matched": [...], "missing": [...]}
    """
    required_list = [s.strip().lower() for s in required_skills.split(",") if s.strip()]
    candidate_set = {s.strip().lower() for s in candidate_skills}

    if not required_list:
        return {"percentage": 0.0, "matched": [], "missing": []}

    matched = [s for s in required_list if s in candidate_set]
    missing = [s for s in required_list if s not in candidate_set]
    percentage = round((len(matched) / len(required_list)) * 100, 2)

    return {"percentage": percentage, "matched": matched, "missing": missing}


def compute_final_score(cosine_score: float, skill_score: float, semantic_score: float = None,
                         cosine_weight: float = 0.6, skill_weight: float = 0.4,
                         semantic_weight: float = 0.0) -> float:
    """
    Blend TF-IDF/cosine similarity, the explicit skill-match percentage,
    and (optionally) an LSA-based semantic similarity score into one
    final Match Score shown to the recruiter. Weights are expected to
    sum to 1.0 when semantic_score is supplied.
    """
    if semantic_score is None:
        return round((cosine_score * cosine_weight) + (skill_score * skill_weight), 2)
    return round(
        (cosine_score * cosine_weight) + (skill_score * skill_weight) + (semantic_score * semantic_weight), 2
    )
