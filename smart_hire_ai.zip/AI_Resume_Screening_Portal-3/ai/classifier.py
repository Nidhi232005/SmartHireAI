"""
ai/classifier.py
------------------
An optional Machine Learning layer that sits on top of the rule-based
scoring pipeline. Instead of a fixed threshold (score >= 60 -> Shortlist),
a Logistic Regression classifier is trained on labeled examples to learn
the relationship between a candidate's feature vector and a hire/no-hire
outcome, and outputs a calibrated probability of being a good fit.

Features used (all already computed elsewhere in the pipeline):
    1. cosine_score        - TF-IDF cosine similarity  (0-100)
    2. semantic_score      - LSA-based semantic similarity (0-100)
    3. skill_match_pct     - required-skill overlap percentage (0-100)
    4. experience_years    - years of experience extracted from resume
    5. education_match     - 1 if resume education matches job education, else 0

Because no proprietary labeled hiring dataset is available for this
academic project, scripts/train_classifier.py generates a realistic
synthetic dataset (with controlled noise) to train and evaluate the
model, and prints/saves standard classification metrics
(accuracy, precision, recall, F1, confusion matrix) so the model's
behaviour is transparent and reproducible.
"""

import os
import json
import joblib
import numpy as np

MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
MODEL_PATH = os.path.join(MODEL_DIR, "resume_classifier.joblib")
METRICS_PATH = os.path.join(MODEL_DIR, "classifier_metrics.json")

FEATURE_NAMES = [
    "cosine_score", "semantic_score", "skill_match_pct",
    "experience_years", "education_match",
]

_model_cache = None


def build_feature_vector(cosine_score, semantic_score, skill_match_pct,
                          experience_years, education_match) -> list:
    return [
        float(cosine_score or 0), float(semantic_score or 0), float(skill_match_pct or 0),
        float(experience_years or 0), 1.0 if education_match else 0.0,
    ]


def is_model_available() -> bool:
    return os.path.exists(MODEL_PATH)


def load_model():
    global _model_cache
    if _model_cache is None:
        if not is_model_available():
            raise FileNotFoundError(
                f"No trained classifier found at {MODEL_PATH}. "
                "Run: python scripts/train_classifier.py"
            )
        _model_cache = joblib.load(MODEL_PATH)
    return _model_cache


def predict_fit_probability(feature_vector: list) -> float:
    """Returns the model's predicted probability (0-100) that this
    candidate is a good fit for the job, based on its learned weights."""
    model = load_model()
    proba = model.predict_proba([feature_vector])[0][1]  # P(class == 1 / "good fit")
    return round(float(proba) * 100, 2)


def get_saved_metrics() -> dict:
    if not os.path.exists(METRICS_PATH):
        return {}
    with open(METRICS_PATH) as f:
        return json.load(f)
