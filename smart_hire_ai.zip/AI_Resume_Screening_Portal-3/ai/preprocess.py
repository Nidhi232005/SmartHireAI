"""
ai/preprocess.py
-----------------
Handles raw text extraction (PDF/DOCX) and NLP text-cleaning:
lowercasing, punctuation removal, stop-word removal, tokenization
and lemmatization.
"""

import re
import string

import nltk
import pdfplumber
import docx

for pkg in ("punkt", "punkt_tab", "stopwords", "wordnet", "omw-1.4"):
    try:
        nltk.data.find(pkg)
    except LookupError:
        nltk.download(pkg, quiet=True)

from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

STOP_WORDS = set(stopwords.words("english"))
LEMMATIZER = WordNetLemmatizer()


def extract_text_from_pdf(file_path: str) -> str:
    text_chunks = []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text_chunks.append(page_text)
    return "\n".join(text_chunks)


def extract_text_from_docx(file_path: str) -> str:
    document = docx.Document(file_path)
    return "\n".join(p.text for p in document.paragraphs if p.text.strip())


def extract_text(file_path: str, file_ext: str) -> str:
    file_ext = file_ext.lower().lstrip(".")
    if file_ext == "pdf":
        return extract_text_from_pdf(file_path)
    elif file_ext == "docx":
        return extract_text_from_docx(file_path)
    raise ValueError(f"Unsupported file type: {file_ext}")


def clean_text(raw_text: str) -> str:
    if not raw_text:
        return ""
    text = raw_text.lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\d+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()

    tokens = word_tokenize(text)
    tokens = [t for t in tokens if t not in STOP_WORDS and len(t) > 1]
    lemmatized = [LEMMATIZER.lemmatize(t) for t in tokens]
    return " ".join(lemmatized)


def tokenize_only(raw_text: str):
    return clean_text(raw_text).split()
