"""
ai/ranking.py
-------------
Takes the per-candidate match scores produced by similarity.py /
semantic_similarity.py (and optionally classifier.py) and turns them
into a ranked list with a Shortlist / Review / Reject recommendation.

Two scoring modes are supported, controlled by Config.USE_ML_CLASSIFIER:
  - RULE_BASED : fixed thresholds on the blended Match Score (default,
                 fully transparent -- see config.SHORTLIST_THRESHOLD/
                 REJECT_THRESHOLD).
  - ML_CLASSIFIER : a trained Logistic Regression model (ai/classifier.py)
                 predicts a probability of being a good fit; that
                 probability drives the recommendation instead.
"""

from config import Config


def recommend_rule_based(score: float) -> str:
    if score >= Config.SHORTLIST_THRESHOLD:
        return "SHORTLIST"
    elif score < Config.REJECT_THRESHOLD:
        return "REJECT"
    return "REVIEW"


def recommend_from_probability(probability: float) -> str:
    """Same three-tier interpretation, but driven by an ML probability (0-100)."""
    if probability >= Config.SHORTLIST_THRESHOLD:
        return "SHORTLIST"
    elif probability < Config.REJECT_THRESHOLD:
        return "REJECT"
    return "REVIEW"


def rank_candidates(candidates: list) -> list:
    """
    candidates: list of dicts, each containing at least a 'final_score' key.
    Returns the same list sorted descending by final_score, with an added
    'rank' (1-based) field. Recommendation is expected to already be set
    by the caller (app.py), since it may come from either scoring mode.
    """
    sorted_candidates = sorted(candidates, key=lambda c: c["final_score"], reverse=True)
    for idx, candidate in enumerate(sorted_candidates, start=1):
        candidate["rank"] = idx
    return sorted_candidates
