"""
ai/feature_extraction.py
-------------------------
Pulls structured information out of raw resume text: contact details,
skills, education, experience, certifications, projects, programming
languages and soft skills.
"""

import re

try:
    import spacy
    _NLP = spacy.load("en_core_web_sm")
except Exception:
    _NLP = None

PROGRAMMING_LANGUAGES = [
    "python", "java", "javascript", "typescript", "c++", "c#", "c",
    "php", "ruby", "go", "golang", "swift", "kotlin", "r", "scala",
    "html", "css", "sql", "matlab", "perl", "rust",
]

TECH_SKILLS = [
    "flask", "django", "react", "angular", "vue", "node.js", "express",
    "bootstrap", "mysql", "postgresql", "mongodb", "sqlite", "aws",
    "azure", "gcp", "docker", "kubernetes", "git", "github", "rest api",
    "graphql", "tensorflow", "pytorch", "scikit-learn", "pandas",
    "numpy", "nltk", "spacy", "tf-idf", "machine learning",
    "deep learning", "nlp", "data analysis", "power bi", "tableau",
    "linux", "jenkins", "ci/cd", "microservices", "firebase", "redux",
]

SOFT_SKILLS = [
    "communication", "teamwork", "leadership", "problem solving",
    "adaptability", "time management", "critical thinking",
    "collaboration", "creativity", "work ethic", "attention to detail",
    "decision making", "conflict resolution", "presentation",
]

EDUCATION_KEYWORDS = [
    "b.tech", "btech", "b.e.", "be ", "m.tech", "mtech", "mca", "bca",
    "bsc", "b.sc", "msc", "m.sc", "phd", "mba", "diploma",
    "bachelor", "master", "doctorate",
]

CERT_KEYWORDS = ["certified", "certification", "certificate"]

EMAIL_RE = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+")
PHONE_RE = re.compile(r"(?:\+?\d{1,3}[\s-]?)?\d{10}")
EXPERIENCE_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\s*(?:of)?\s*experience", re.IGNORECASE
)


def _find_keywords(text_lower: str, bank: list) -> list:
    return sorted({kw for kw in bank if kw in text_lower})


def extract_name(raw_text: str) -> str:
    if _NLP:
        doc = _NLP(raw_text[:1000])
        for ent in doc.ents:
            if ent.label_ == "PERSON":
                return ent.text.strip()
    first_line = raw_text.strip().split("\n")[0].strip()
    return first_line[:100] if first_line else "Unknown Candidate"


def extract_email(raw_text: str) -> str:
    match = EMAIL_RE.search(raw_text)
    return match.group(0) if match else ""


def extract_phone(raw_text: str) -> str:
    match = PHONE_RE.search(raw_text)
    return match.group(0) if match else ""


def extract_experience(raw_text: str) -> str:
    match = EXPERIENCE_RE.search(raw_text)
    if match:
        return f"{match.group(1)} years"
    return "Not specified"


def extract_experience_years(raw_text: str) -> float:
    """Numeric version of extract_experience, used as an ML feature."""
    match = EXPERIENCE_RE.search(raw_text)
    return float(match.group(1)) if match else 0.0


def extract_education(raw_text: str) -> str:
    text_lower = raw_text.lower()
    hits = [kw for kw in EDUCATION_KEYWORDS if kw in text_lower]
    return ", ".join(sorted(set(hits))).upper() if hits else "Not specified"


def extract_skills(raw_text: str) -> dict:
    text_lower = raw_text.lower()
    return {
        "programming_languages": _find_keywords(text_lower, PROGRAMMING_LANGUAGES),
        "technical_skills": _find_keywords(text_lower, TECH_SKILLS),
        "soft_skills": _find_keywords(text_lower, SOFT_SKILLS),
    }


def extract_certifications(raw_text: str) -> list:
    lines = raw_text.split("\n")
    return [
        line.strip() for line in lines
        if any(k in line.lower() for k in CERT_KEYWORDS) and len(line.strip()) < 150
    ][:10]


def extract_projects(raw_text: str) -> list:
    lines = raw_text.split("\n")
    projects, capturing = [], False
    for line in lines:
        stripped = line.strip()
        if re.match(r"^(projects?|academic projects?)\s*:?$", stripped, re.IGNORECASE):
            capturing = True
            continue
        if capturing:
            if re.match(r"^[A-Z][A-Za-z ]{2,30}:?$", stripped) and len(stripped) < 30:
                if stripped.lower() not in ("projects", "project"):
                    break
            if stripped:
                projects.append(stripped)
    return projects[:10]


def extract_all_features(raw_text: str) -> dict:
    skills = extract_skills(raw_text)
    all_skills_flat = sorted(set(
        skills["programming_languages"] + skills["technical_skills"] + skills["soft_skills"]
    ))
    return {
        "name": extract_name(raw_text),
        "email": extract_email(raw_text),
        "phone": extract_phone(raw_text),
        "education": extract_education(raw_text),
        "experience": extract_experience(raw_text),
        "experience_years": extract_experience_years(raw_text),
        "programming_languages": skills["programming_languages"],
        "technical_skills": skills["technical_skills"],
        "soft_skills": skills["soft_skills"],
        "skills_flat": all_skills_flat,
        "certifications": extract_certifications(raw_text),
        "projects": extract_projects(raw_text),
    }
