"""
app.py
------
Main Flask application entry point for the AI-Based Resume Screening and
Recruitment Portal. Wires together authentication, job management, public
job applications, resume upload/processing (single + bulk ZIP), AI
screening (rule-based + optional ML classifier), a Kanban hiring pipeline,
interview scheduling, email notifications, candidate management, and
reporting (including skill-gap analysis and a hiring funnel).

Run locally with:
    python app.py
"""

import os
import io
import csv
import json
import logging
import secrets
import zipfile
from datetime import datetime, timedelta
from collections import Counter

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, jsonify, send_from_directory, Response
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_wtf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_mail import Mail, Message

from config import Config
from database import run_query, init_db
from ai.preprocess import extract_text
from ai.feature_extraction import extract_all_features
from ai.similarity import compute_match_scores, compute_skill_match, compute_final_score
from ai.semantic_similarity import compute_semantic_scores
from ai.ranking import recommend_rule_based, recommend_from_probability, rank_candidates
from ai import classifier as ml_classifier

# ======================================================================
# App setup
# ======================================================================
app = Flask(__name__)
app.config.from_object(Config)

os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
os.makedirs(os.path.dirname(Config.LOG_FILE), exist_ok=True)

# ---- Logging ----
logging.basicConfig(
    level=getattr(logging, Config.LOG_LEVEL, logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.FileHandler(Config.LOG_FILE), logging.StreamHandler()],
)
logger = logging.getLogger("resumeai.app")

# ---- CSRF protection (Flask-WTF) ----
csrf = CSRFProtect(app)

# ---- Rate limiting (Flask-Limiter) ----
limiter = Limiter(get_remote_address, app=app, storage_uri=Config.RATELIMIT_STORAGE_URI,
                   default_limits=[])

# ---- Email (Flask-Mail) ----
app.config.update(
    MAIL_SERVER=Config.MAIL_SERVER, MAIL_PORT=Config.MAIL_PORT,
    MAIL_USE_TLS=Config.MAIL_USE_TLS, MAIL_USERNAME=Config.MAIL_USERNAME,
    MAIL_PASSWORD=Config.MAIL_PASSWORD, MAIL_DEFAULT_SENDER=Config.MAIL_DEFAULT_SENDER,
)
mail = Mail(app)


# ======================================================================
# Helpers
# ======================================================================
def allowed_resume_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS


def allowed_bulk_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_BULK_EXTENSIONS


def login_required(view_func):
    from functools import wraps

    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)
    return wrapped


def current_user():
    if "user_id" not in session:
        return None
    return run_query(
        "SELECT user_id, full_name, email, company_name, role FROM users WHERE user_id = %s",
        (session["user_id"],), fetch_one=True,
    )


@app.context_processor
def inject_user():
    return {"logged_in_user": current_user() if "user_id" in session else None}


def send_status_email(candidate, new_status, job_title):
    """Best-effort candidate status notification. No-ops safely if email
    is not configured or the candidate has no email on file, so the core
    workflow never breaks because of a missing SMTP setup."""
    if not Config.MAIL_ENABLED:
        logger.info("MAIL_ENABLED=0 — skipping email to %s (status=%s)", candidate.get("email"), new_status)
        return
    if not candidate.get("email"):
        return

    subject_map = {
        "SHORTLISTED": f"You've been shortlisted for {job_title}",
        "INTERVIEW": f"Interview scheduled for {job_title}",
        "HIRED": f"Congratulations — offer for {job_title}",
        "REJECTED": f"Update on your application for {job_title}",
    }
    body_map = {
        "SHORTLISTED": f"Hi {candidate.get('full_name', 'Candidate')},\n\nGreat news — you have been shortlisted for the {job_title} role. Our team will reach out soon with next steps.",
        "INTERVIEW": f"Hi {candidate.get('full_name', 'Candidate')},\n\nYou have an interview scheduled for the {job_title} role. Please check your dashboard/email for details.",
        "HIRED": f"Hi {candidate.get('full_name', 'Candidate')},\n\nCongratulations! We are excited to move forward with an offer for the {job_title} role.",
        "REJECTED": f"Hi {candidate.get('full_name', 'Candidate')},\n\nThank you for applying for the {job_title} role. After careful review, we will not be proceeding with your application at this time.",
    }
    if new_status not in subject_map:
        return
    try:
        msg = Message(subject_map[new_status], recipients=[candidate["email"]], body=body_map[new_status])
        mail.send(msg)
        logger.info("Sent '%s' status email to %s", new_status, candidate["email"])
    except Exception:
        logger.exception("Failed to send status email to %s", candidate.get("email"))


def record_status_change(candidate_id, old_status, new_status):
    run_query(
        "INSERT INTO candidate_status_history (candidate_id, old_status, new_status) VALUES (%s,%s,%s)",
        (candidate_id, old_status, new_status), commit=True,
    )


# ======================================================================
# Authentication
# ======================================================================
@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        company_name = request.form.get("company_name", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        errors = []
        if len(full_name) < 2:
            errors.append("Please enter your full name.")
        if "@" not in email or "." not in email:
            errors.append("Please enter a valid email address.")
        if len(password) < 8:
            errors.append("Password must be at least 8 characters long.")
        if password != confirm_password:
            errors.append("Passwords do not match.")

        existing = run_query("SELECT user_id FROM users WHERE email = %s", (email,), fetch_one=True)
        if existing:
            errors.append("An account with this email already exists.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("register.html", form=request.form)

        password_hash = generate_password_hash(password)
        run_query(
            "INSERT INTO users (full_name, email, password_hash, company_name, role) "
            "VALUES (%s, %s, %s, %s, 'HR')",
            (full_name, email, password_hash, company_name), commit=True,
        )
        logger.info("New HR account registered: %s", email)
        flash("Account created successfully. Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html", form={})


@app.route("/login", methods=["GET", "POST"])
@limiter.limit(lambda: Config.LOGIN_RATE_LIMIT)
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = run_query("SELECT * FROM users WHERE email = %s", (email,), fetch_one=True)
        if not user or not check_password_hash(user["password_hash"], password):
            logger.warning("Failed login attempt for %s", email)
            flash("Invalid email or password.", "danger")
            return render_template("login.html")

        session.permanent = True
        session["user_id"] = user["user_id"]
        session["full_name"] = user["full_name"]
        logger.info("User logged in: %s", email)
        flash(f"Welcome back, {user['full_name']}!", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = run_query("SELECT user_id FROM users WHERE email = %s", (email,), fetch_one=True)

        if user:
            token = secrets.token_urlsafe(32)
            expires = datetime.utcnow() + timedelta(hours=1)
            run_query(
                "UPDATE users SET reset_token = %s, reset_expires = %s WHERE user_id = %s",
                (token, expires, user["user_id"]), commit=True,
            )
            flash(
                f"Password reset link generated: /reset-password/{token} "
                "(in production this is emailed to you).", "info"
            )
        else:
            flash("If that email exists, a reset link has been sent.", "info")
        return redirect(url_for("login"))

    return render_template("forgot_password.html")


@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    user = run_query(
        "SELECT user_id FROM users WHERE reset_token = %s AND reset_expires > %s",
        (token, datetime.utcnow()), fetch_one=True,
    )
    if not user:
        flash("This reset link is invalid or has expired.", "danger")
        return redirect(url_for("forgot_password"))

    if request.method == "POST":
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")
        if len(password) < 8 or password != confirm_password:
            flash("Passwords must match and be at least 8 characters.", "danger")
            return render_template("reset_password.html", token=token)

        run_query(
            "UPDATE users SET password_hash = %s, reset_token = NULL, reset_expires = NULL "
            "WHERE user_id = %s",
            (generate_password_hash(password), user["user_id"]), commit=True,
        )
        flash("Password updated. Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("reset_password.html", token=token)


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# ======================================================================
# Dashboard
# ======================================================================
@app.route("/dashboard")
@login_required
def dashboard():
    uid = session["user_id"]

    total_jobs = run_query("SELECT COUNT(*) AS c FROM jobs WHERE posted_by = %s", (uid,), fetch_one=True)["c"]
    active_jobs = run_query(
        "SELECT COUNT(*) AS c FROM jobs WHERE posted_by = %s AND status='ACTIVE'", (uid,), fetch_one=True
    )["c"]
    total_applicants = run_query(
        "SELECT COUNT(*) AS c FROM candidates c JOIN jobs j ON c.job_id=j.job_id WHERE j.posted_by=%s",
        (uid,), fetch_one=True
    )["c"]
    shortlisted = run_query(
        "SELECT COUNT(*) AS c FROM candidates c JOIN jobs j ON c.job_id=j.job_id "
        "WHERE j.posted_by=%s AND c.status IN ('SHORTLISTED','INTERVIEW','HIRED')", (uid,), fetch_one=True
    )["c"]
    rejected = run_query(
        "SELECT COUNT(*) AS c FROM candidates c JOIN jobs j ON c.job_id=j.job_id "
        "WHERE j.posted_by=%s AND c.status='REJECTED'", (uid,), fetch_one=True
    )["c"]
    hired = run_query(
        "SELECT COUNT(*) AS c FROM candidates c JOIN jobs j ON c.job_id=j.job_id "
        "WHERE j.posted_by=%s AND c.status='HIRED'", (uid,), fetch_one=True
    )["c"]

    recent_applications = run_query(
        "SELECT c.full_name, c.email, c.status, c.created_at, j.job_title "
        "FROM candidates c JOIN jobs j ON c.job_id=j.job_id "
        "WHERE j.posted_by=%s ORDER BY c.created_at DESC LIMIT 6",
        (uid,), fetch=True
    )

    score_trend = run_query(
        "SELECT j.job_title, AVG(rs.match_score) AS avg_score "
        "FROM resume_scores rs JOIN jobs j ON rs.job_id=j.job_id "
        "WHERE j.posted_by=%s GROUP BY j.job_id ORDER BY j.created_at DESC LIMIT 6",
        (uid,), fetch=True
    )

    upcoming_interviews = run_query(
        "SELECT i.*, c.full_name, j.job_title FROM interviews i "
        "JOIN candidates c ON i.candidate_id=c.candidate_id "
        "JOIN jobs j ON i.job_id=j.job_id "
        "WHERE j.posted_by=%s AND i.status='SCHEDULED' AND i.scheduled_at >= NOW() "
        "ORDER BY i.scheduled_at ASC LIMIT 5",
        (uid,), fetch=True
    )

    status_breakdown = {
        "shortlisted": shortlisted,
        "rejected": rejected,
        "pending": max(total_applicants - shortlisted - rejected, 0),
    }

    return render_template(
        "dashboard.html",
        total_jobs=total_jobs, active_jobs=active_jobs,
        total_applicants=total_applicants, shortlisted=shortlisted,
        rejected=rejected, hired=hired, recent_applications=recent_applications,
        score_trend=score_trend, status_breakdown=status_breakdown,
        upcoming_interviews=upcoming_interviews,
        use_ml_classifier=Config.USE_ML_CLASSIFIER,
        ml_available=ml_classifier.is_model_available(),
    )


# ======================================================================
# Job Management
# ======================================================================
@app.route("/jobs")
@login_required
def jobs():
    search = request.args.get("q", "").strip()
    uid = session["user_id"]

    if search:
        like = f"%{search}%"
        job_list = run_query(
            "SELECT * FROM jobs WHERE posted_by=%s AND "
            "(job_title LIKE %s OR company LIKE %s OR location LIKE %s) "
            "ORDER BY created_at DESC",
            (uid, like, like, like), fetch=True
        )
    else:
        job_list = run_query(
            "SELECT * FROM jobs WHERE posted_by=%s ORDER BY created_at DESC", (uid,), fetch=True
        )

    return render_template("jobs.html", jobs=job_list, search=search)


@app.route("/jobs/new", methods=["GET", "POST"])
@login_required
def job_new():
    if request.method == "POST":
        data = request.form
        errors = []
        for field in ("job_title", "company", "location", "experience_req",
                      "required_skills", "education", "job_description"):
            if not data.get(field, "").strip():
                errors.append(f"'{field.replace('_', ' ').title()}' is required.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("job_form.html", job=data, mode="create")

        is_public = 1 if data.get("is_public") == "on" else 0
        run_query(
            "INSERT INTO jobs (posted_by, job_title, company, location, experience_req, "
            "required_skills, education, salary, job_description, status, is_public) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,'ACTIVE',%s)",
            (session["user_id"], data["job_title"], data["company"], data["location"],
             data["experience_req"], data["required_skills"], data["education"],
             data.get("salary", ""), data["job_description"], is_public),
            commit=True,
        )
        flash("Job posted successfully.", "success")
        return redirect(url_for("jobs"))

    return render_template("job_form.html", job={}, mode="create")


@app.route("/jobs/<int:job_id>/edit", methods=["GET", "POST"])
@login_required
def job_edit(job_id):
    job = run_query(
        "SELECT * FROM jobs WHERE job_id=%s AND posted_by=%s",
        (job_id, session["user_id"]), fetch_one=True
    )
    if not job:
        flash("Job not found.", "danger")
        return redirect(url_for("jobs"))

    if request.method == "POST":
        data = request.form
        is_public = 1 if data.get("is_public") == "on" else 0
        run_query(
            "UPDATE jobs SET job_title=%s, company=%s, location=%s, experience_req=%s, "
            "required_skills=%s, education=%s, salary=%s, job_description=%s, status=%s, is_public=%s "
            "WHERE job_id=%s AND posted_by=%s",
            (data["job_title"], data["company"], data["location"], data["experience_req"],
             data["required_skills"], data["education"], data.get("salary", ""),
             data["job_description"], data.get("status", "ACTIVE"), is_public,
             job_id, session["user_id"]),
            commit=True,
        )
        flash("Job updated successfully.", "success")
        return redirect(url_for("jobs"))

    return render_template("job_form.html", job=job, mode="edit")


@app.route("/jobs/<int:job_id>/delete", methods=["POST"])
@login_required
def job_delete(job_id):
    run_query("DELETE FROM jobs WHERE job_id=%s AND posted_by=%s", (job_id, session["user_id"]), commit=True)
    flash("Job deleted.", "info")
    return redirect(url_for("jobs"))


# ======================================================================
# Public Careers Page + Candidate Self-Application
# ======================================================================
@app.route("/careers")
def careers():
    search = request.args.get("q", "").strip()
    if search:
        like = f"%{search}%"
        job_list = run_query(
            "SELECT j.*, u.company_name FROM jobs j JOIN users u ON j.posted_by=u.user_id "
            "WHERE j.is_public=1 AND j.status='ACTIVE' AND "
            "(j.job_title LIKE %s OR j.company LIKE %s OR j.location LIKE %s) ORDER BY j.created_at DESC",
            (like, like, like), fetch=True
        )
    else:
        job_list = run_query(
            "SELECT j.*, u.company_name FROM jobs j JOIN users u ON j.posted_by=u.user_id "
            "WHERE j.is_public=1 AND j.status='ACTIVE' ORDER BY j.created_at DESC",
            fetch=True
        )
    return render_template("careers.html", jobs=job_list, search=search)


@app.route("/careers/<int:job_id>", methods=["GET", "POST"])
def careers_apply(job_id):
    job = run_query("SELECT * FROM jobs WHERE job_id=%s AND is_public=1 AND status='ACTIVE'",
                     (job_id,), fetch_one=True)
    if not job:
        flash("This job posting is no longer available.", "warning")
        return redirect(url_for("careers"))

    if request.method == "POST":
        file = request.files.get("resume")
        applicant_name = request.form.get("applicant_name", "").strip()
        applicant_email = request.form.get("applicant_email", "").strip()

        if not applicant_name or not applicant_email:
            flash("Please provide your name and email.", "danger")
            return render_template("careers_apply.html", job=job)

        if not file or file.filename == "" or not allowed_resume_file(file.filename):
            flash("Please upload a valid PDF or DOCX resume.", "danger")
            return render_template("careers_apply.html", job=job)

        job_folder = os.path.join(Config.UPLOAD_FOLDER, f"job_{job_id}")
        os.makedirs(job_folder, exist_ok=True)
        filename = secure_filename(file.filename)
        unique_name = f"{secrets.token_hex(6)}_{filename}"
        stored_path = os.path.join(job_folder, unique_name)
        file.save(stored_path)

        file_ext = filename.rsplit(".", 1)[1].lower()
        try:
            raw_text = extract_text(stored_path, file_ext)
        except Exception as exc:
            logger.exception("Failed to parse publicly-submitted resume")
            flash(f"Could not read your resume file: {exc}", "danger")
            return render_template("careers_apply.html", job=job)

        features = extract_all_features(raw_text)
        candidate_id = run_query(
            "INSERT INTO candidates (job_id, full_name, email, phone, education, experience, "
            "skills, source, status) VALUES (%s,%s,%s,%s,%s,%s,%s,'PUBLIC_APPLICATION','PENDING')",
            (job_id, applicant_name or features["name"], applicant_email or features["email"],
             features["phone"], features["education"], features["experience"],
             ", ".join(features["skills_flat"])),
            commit=True,
        )
        run_query(
            "INSERT INTO uploaded_resumes (candidate_id, original_name, stored_path, file_type, raw_text) "
            "VALUES (%s,%s,%s,%s,%s)",
            (candidate_id, filename, stored_path, file_ext, raw_text), commit=True,
        )
        record_status_change(candidate_id, None, "PENDING")

        _score_and_store(job, [candidate_id], [raw_text])
        flash("Your application has been submitted successfully! Our team will review it shortly.", "success")
        return redirect(url_for("careers"))

    return render_template("careers_apply.html", job=job)


# ======================================================================
# Resume Upload & AI Screening (single + bulk ZIP)
# ======================================================================
@app.route("/jobs/<int:job_id>/upload", methods=["GET", "POST"])
@login_required
def upload_resume(job_id):
    job = run_query(
        "SELECT * FROM jobs WHERE job_id=%s AND posted_by=%s",
        (job_id, session["user_id"]), fetch_one=True
    )
    if not job:
        flash("Job not found.", "danger")
        return redirect(url_for("jobs"))

    if request.method == "POST":
        files = request.files.getlist("resumes")
        zip_file = request.files.get("resume_zip")

        job_folder = os.path.join(Config.UPLOAD_FOLDER, f"job_{job_id}")
        os.makedirs(job_folder, exist_ok=True)

        pending_files = []  # list of (filename, filesystem_path_to_read_bytes_from)

        if zip_file and zip_file.filename and allowed_bulk_file(zip_file.filename):
            pending_files.extend(_extract_resumes_from_zip(zip_file, job_folder))
        elif files and files[0].filename != "":
            for file in files:
                if not file or not allowed_resume_file(file.filename):
                    flash(f"Skipped unsupported file: {file.filename}", "warning")
                    continue
                filename = secure_filename(file.filename)
                unique_name = f"{secrets.token_hex(6)}_{filename}"
                stored_path = os.path.join(job_folder, unique_name)
                file.save(stored_path)
                pending_files.append((filename, stored_path))
        else:
            flash("Please select at least one resume file or a ZIP archive.", "warning")
            return redirect(url_for("upload_resume", job_id=job_id))

        new_candidate_ids, resume_texts = [], []

        for filename, stored_path in pending_files:
            file_ext = filename.rsplit(".", 1)[1].lower()
            try:
                raw_text = extract_text(stored_path, file_ext)
            except Exception as exc:
                logger.exception("Failed to parse %s", filename)
                flash(f"Could not read {filename}: {exc}", "danger")
                continue

            features = extract_all_features(raw_text)
            candidate_id = run_query(
                "INSERT INTO candidates (job_id, full_name, email, phone, education, "
                "experience, skills, source, status) VALUES (%s,%s,%s,%s,%s,%s,%s,'HR_UPLOAD','PENDING')",
                (job_id, features["name"], features["email"], features["phone"],
                 features["education"], features["experience"], ", ".join(features["skills_flat"])),
                commit=True,
            )
            run_query(
                "INSERT INTO uploaded_resumes (candidate_id, original_name, stored_path, "
                "file_type, raw_text) VALUES (%s,%s,%s,%s,%s)",
                (candidate_id, filename, stored_path, file_ext, raw_text), commit=True,
            )
            record_status_change(candidate_id, None, "PENDING")

            new_candidate_ids.append(candidate_id)
            resume_texts.append(raw_text)

        if resume_texts:
            _score_and_store(job, new_candidate_ids, resume_texts)
            flash(f"{len(resume_texts)} resume(s) uploaded and screened successfully.", "success")

        return redirect(url_for("candidates_view", job_id=job_id))

    return render_template("upload_resume.html", job=job)


def _extract_resumes_from_zip(zip_file_storage, job_folder):
    """Extracts PDF/DOCX files from an uploaded ZIP archive (bulk upload)."""
    extracted = []
    zip_bytes = io.BytesIO(zip_file_storage.read())
    try:
        with zipfile.ZipFile(zip_bytes) as zf:
            for member in zf.namelist():
                if member.endswith("/"):
                    continue
                base_name = os.path.basename(member)
                if not base_name or not allowed_resume_file(base_name):
                    continue
                safe_name = secure_filename(base_name)
                unique_name = f"{secrets.token_hex(6)}_{safe_name}"
                target_path = os.path.join(job_folder, unique_name)
                with zf.open(member) as src, open(target_path, "wb") as dst:
                    dst.write(src.read())
                extracted.append((safe_name, target_path))
    except zipfile.BadZipFile:
        flash("The uploaded ZIP file is invalid or corrupted.", "danger")
    return extracted


def _score_and_store(job, candidate_ids, resume_texts):
    """Runs the full AI pipeline (TF-IDF cosine + LSA semantic + skill match
    [+ optional ML classifier]) and persists scores."""
    cosine_scores = compute_match_scores(job["job_description"], resume_texts)
    semantic_scores = (
        compute_semantic_scores(job["job_description"], resume_texts)
        if Config.USE_SEMANTIC_MATCHING else [0.0] * len(resume_texts)
    )

    use_ml = Config.USE_ML_CLASSIFIER and ml_classifier.is_model_available()

    for cid, cosine_score, semantic_score, raw_text in zip(candidate_ids, cosine_scores, semantic_scores, resume_texts):
        features = extract_all_features(raw_text)
        skill_result = compute_skill_match(job["required_skills"], features["skills_flat"])

        final_score = compute_final_score(
            cosine_score, skill_result["percentage"], semantic_score,
            cosine_weight=Config.COSINE_WEIGHT, skill_weight=Config.SKILL_WEIGHT,
            semantic_weight=Config.SEMANTIC_WEIGHT,
        )

        ml_probability = None
        scoring_method = "RULE_BASED"
        if use_ml:
            education_match = 1 if job["education"].split(",")[0].strip().lower() in (features["education"] or "").lower() else 0
            try:
                feature_vector = ml_classifier.build_feature_vector(
                    cosine_score, semantic_score, skill_result["percentage"],
                    features["experience_years"], education_match,
                )
                ml_probability = ml_classifier.predict_fit_probability(feature_vector)
                recommendation = recommend_from_probability(ml_probability)
                scoring_method = "ML_CLASSIFIER"
            except Exception:
                logger.exception("ML classifier prediction failed; falling back to rule-based")
                recommendation = recommend_rule_based(final_score)
        else:
            recommendation = recommend_rule_based(final_score)

        run_query(
            "INSERT INTO resume_scores (candidate_id, job_id, cosine_score, semantic_score, match_score, "
            "skill_match_pct, matched_skills, missing_skills, recommendation, ml_probability, scoring_method) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (cid, job["job_id"], cosine_score, semantic_score, final_score, skill_result["percentage"],
             ", ".join(skill_result["matched"]), ", ".join(skill_result["missing"]), recommendation,
             ml_probability, scoring_method),
            commit=True,
        )

    _recompute_ranks(job["job_id"])


def _recompute_ranks(job_id):
    rows = run_query(
        "SELECT score_id, candidate_id, match_score FROM resume_scores "
        "WHERE job_id=%s ORDER BY match_score DESC", (job_id,), fetch=True
    )
    for idx, row in enumerate(rows, start=1):
        run_query("UPDATE resume_scores SET rank_position=%s WHERE score_id=%s", (idx, row["score_id"]), commit=True)


# ======================================================================
# Candidate Management
# ======================================================================
@app.route("/jobs/<int:job_id>/candidates")
@login_required
def candidates_view(job_id):
    job = run_query(
        "SELECT * FROM jobs WHERE job_id=%s AND posted_by=%s",
        (job_id, session["user_id"]), fetch_one=True
    )
    if not job:
        flash("Job not found.", "danger")
        return redirect(url_for("jobs"))

    search = request.args.get("q", "").strip()
    status_filter = request.args.get("status", "")
    sort_by = request.args.get("sort", "score")

    query = (
        "SELECT c.*, rs.match_score, rs.cosine_score, rs.semantic_score, rs.skill_match_pct, "
        "rs.matched_skills, rs.missing_skills, rs.rank_position, rs.recommendation, "
        "rs.ml_probability, rs.scoring_method "
        "FROM candidates c LEFT JOIN resume_scores rs ON c.candidate_id = rs.candidate_id "
        "WHERE c.job_id=%s"
    )
    params = [job_id]

    if search:
        query += " AND (c.full_name LIKE %s OR c.email LIKE %s OR c.skills LIKE %s)"
        like = f"%{search}%"
        params += [like, like, like]

    if status_filter:
        query += " AND c.status=%s"
        params.append(status_filter)

    if sort_by == "score":
        query += " ORDER BY rs.match_score DESC"
    elif sort_by == "name":
        query += " ORDER BY c.full_name ASC"
    else:
        query += " ORDER BY c.created_at DESC"

    candidate_list = run_query(query, tuple(params), fetch=True)

    return render_template(
        "candidates.html", job=job, candidates=candidate_list,
        search=search, status_filter=status_filter, sort_by=sort_by,
    )


@app.route("/jobs/<int:job_id>/pipeline")
@login_required
def pipeline_view(job_id):
    """Kanban-style hiring pipeline board for a job."""
    job = run_query(
        "SELECT * FROM jobs WHERE job_id=%s AND posted_by=%s",
        (job_id, session["user_id"]), fetch_one=True
    )
    if not job:
        flash("Job not found.", "danger")
        return redirect(url_for("jobs"))

    candidate_list = run_query(
        "SELECT c.*, rs.match_score FROM candidates c "
        "LEFT JOIN resume_scores rs ON c.candidate_id = rs.candidate_id "
        "WHERE c.job_id=%s ORDER BY rs.match_score DESC",
        (job_id,), fetch=True
    )

    columns = ["APPLIED", "PENDING", "SHORTLISTED", "INTERVIEW", "HIRED", "REJECTED"]
    board = {col: [] for col in columns}
    for c in candidate_list:
        board.setdefault(c["status"], []).append(c)

    return render_template("pipeline.html", job=job, board=board, columns=columns)


@app.route("/candidates/<int:candidate_id>/status", methods=["POST"])
@login_required
def update_candidate_status(candidate_id):
    """Handles both the classic dropdown form post and JSON requests from
    the Kanban board's drag-and-drop interface."""
    if request.is_json:
        new_status = request.json.get("status")
    else:
        new_status = request.form.get("status")

    valid_statuses = ("APPLIED", "PENDING", "SHORTLISTED", "INTERVIEW", "HIRED", "REJECTED")
    if new_status not in valid_statuses:
        if request.is_json:
            return jsonify({"error": "Invalid status"}), 400
        flash("Invalid status.", "danger")
        return redirect(request.referrer or url_for("dashboard"))

    candidate = run_query(
        "SELECT c.*, j.job_title FROM candidates c JOIN jobs j ON c.job_id=j.job_id "
        "WHERE c.candidate_id=%s", (candidate_id,), fetch_one=True
    )
    if not candidate:
        if request.is_json:
            return jsonify({"error": "Candidate not found"}), 404
        flash("Candidate not found.", "danger")
        return redirect(request.referrer or url_for("dashboard"))

    old_status = candidate["status"]
    run_query("UPDATE candidates SET status=%s WHERE candidate_id=%s", (new_status, candidate_id), commit=True)
    record_status_change(candidate_id, old_status, new_status)
    send_status_email(candidate, new_status, candidate["job_title"])

    if request.is_json:
        return jsonify({"success": True, "candidate_id": candidate_id, "status": new_status})

    flash("Candidate status updated.", "success")
    return redirect(request.referrer or url_for("dashboard"))


@app.route("/resumes/<int:resume_id>/download")
@login_required
def download_resume(resume_id):
    resume = run_query("SELECT * FROM uploaded_resumes WHERE resume_id=%s", (resume_id,), fetch_one=True)
    if not resume:
        flash("Resume not found.", "danger")
        return redirect(url_for("dashboard"))
    directory, filename = os.path.split(resume["stored_path"])
    return send_from_directory(directory, filename, as_attachment=True, download_name=resume["original_name"])


@app.route("/candidates/<int:candidate_id>/preview")
@login_required
def preview_resume_by_candidate(candidate_id):
    resume = run_query(
        "SELECT * FROM uploaded_resumes WHERE candidate_id=%s ORDER BY uploaded_at DESC LIMIT 1",
        (candidate_id,), fetch_one=True
    )
    if not resume:
        return jsonify({"error": "Resume not found"}), 404
    text = resume["raw_text"][:5000] if resume["raw_text"] else "No text extracted."
    return jsonify({"raw_text": text})


# ======================================================================
# Interview Scheduling
# ======================================================================
@app.route("/candidates/<int:candidate_id>/schedule-interview", methods=["GET", "POST"])
@login_required
def schedule_interview(candidate_id):
    candidate = run_query(
        "SELECT c.*, j.job_title, j.job_id FROM candidates c JOIN jobs j ON c.job_id=j.job_id "
        "WHERE c.candidate_id=%s AND j.posted_by=%s", (candidate_id, session["user_id"]), fetch_one=True
    )
    if not candidate:
        flash("Candidate not found.", "danger")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        scheduled_at = request.form.get("scheduled_at")
        mode = request.form.get("mode", "ONLINE")
        location_or_link = request.form.get("location_or_link", "").strip()
        notes = request.form.get("notes", "").strip()

        if not scheduled_at:
            flash("Please choose a date and time for the interview.", "danger")
            return render_template("schedule_interview.html", candidate=candidate)

        run_query(
            "INSERT INTO interviews (candidate_id, job_id, scheduled_by, scheduled_at, mode, "
            "location_or_link, notes, status) VALUES (%s,%s,%s,%s,%s,%s,%s,'SCHEDULED')",
            (candidate_id, candidate["job_id"], session["user_id"], scheduled_at, mode,
             location_or_link, notes), commit=True,
        )

        old_status = candidate["status"]
        run_query("UPDATE candidates SET status='INTERVIEW' WHERE candidate_id=%s", (candidate_id,), commit=True)
        record_status_change(candidate_id, old_status, "INTERVIEW")
        send_status_email(candidate, "INTERVIEW", candidate["job_title"])

        flash("Interview scheduled successfully.", "success")
        return redirect(url_for("candidates_view", job_id=candidate["job_id"]))

    return render_template("schedule_interview.html", candidate=candidate)


@app.route("/interviews")
@login_required
def interviews_list():
    uid = session["user_id"]
    upcoming = run_query(
        "SELECT i.*, c.full_name, c.email, j.job_title FROM interviews i "
        "JOIN candidates c ON i.candidate_id=c.candidate_id JOIN jobs j ON i.job_id=j.job_id "
        "WHERE j.posted_by=%s ORDER BY i.scheduled_at ASC", (uid,), fetch=True
    )
    return render_template("interviews.html", interviews=upcoming)


# ======================================================================
# Reports (incl. skill-gap analysis + hiring funnel)
# ======================================================================
@app.route("/reports")
@login_required
def reports():
    uid = session["user_id"]
    job_list = run_query(
        "SELECT job_id, job_title FROM jobs WHERE posted_by=%s ORDER BY created_at DESC", (uid,), fetch=True
    )
    selected_job_id = request.args.get("job_id", type=int)

    report_data = _build_report(selected_job_id, uid) if selected_job_id else None
    return render_template("reports.html", jobs=job_list, report=report_data, selected_job_id=selected_job_id)


def _build_report(job_id, uid):
    job = run_query("SELECT * FROM jobs WHERE job_id=%s AND posted_by=%s", (job_id, uid), fetch_one=True)
    if not job:
        return None

    scores = run_query(
        "SELECT rs.*, c.full_name, c.skills, c.status FROM resume_scores rs "
        "JOIN candidates c ON rs.candidate_id = c.candidate_id "
        "WHERE rs.job_id=%s ORDER BY rs.match_score DESC", (job_id,), fetch=True
    )

    total_applications = len(scores)
    avg_score = round(sum(s["match_score"] for s in scores) / total_applications, 2) if scores else 0
    highest = max((s["match_score"] for s in scores), default=0)
    lowest = min((s["match_score"] for s in scores), default=0)

    skill_counter = Counter()
    missing_skill_counter = Counter()
    for s in scores:
        for skill in (s["skills"] or "").split(","):
            skill = skill.strip().lower()
            if skill:
                skill_counter[skill] += 1
        for skill in (s["missing_skills"] or "").split(","):
            skill = skill.strip().lower()
            if skill:
                missing_skill_counter[skill] += 1

    top_skills = skill_counter.most_common(8)
    top_missing_skills = missing_skill_counter.most_common(8)

    funnel_order = ["APPLIED", "PENDING", "SHORTLISTED", "INTERVIEW", "HIRED", "REJECTED"]
    funnel_counts = Counter(s["status"] for s in scores)
    funnel = [{"stage": stage, "count": funnel_counts.get(stage, 0)} for stage in funnel_order]

    return {
        "job": job, "scores": scores, "total_applications": total_applications,
        "avg_score": avg_score, "highest": highest, "lowest": lowest,
        "top_skills": top_skills, "top_missing_skills": top_missing_skills,
        "funnel": funnel,
    }


@app.route("/reports/<int:job_id>/export/csv")
@login_required
def export_report_csv(job_id):
    report = _build_report(job_id, session["user_id"])
    if not report:
        flash("Report not found.", "danger")
        return redirect(url_for("reports"))

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Rank", "Candidate", "Match Score (%)", "Skill Match (%)", "Recommendation", "Status"])
    for s in report["scores"]:
        writer.writerow([s["rank_position"], s["full_name"], s["match_score"],
                          s["skill_match_pct"], s["recommendation"], s["status"]])

    return Response(output.getvalue(), mimetype="text/csv",
                     headers={"Content-Disposition": f"attachment;filename=report_job_{job_id}.csv"})


@app.route("/reports/<int:job_id>/export/pdf")
@login_required
def export_report_pdf(job_id):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet

    report = _build_report(job_id, session["user_id"])
    if not report:
        flash("Report not found.", "danger")
        return redirect(url_for("reports"))

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = [
        Paragraph(f"Hiring Report — {report['job']['job_title']}", styles["Title"]),
        Spacer(1, 12),
        Paragraph(
            f"Total Applications: {report['total_applications']} | "
            f"Average Score: {report['avg_score']}% | "
            f"Highest: {report['highest']}% | Lowest: {report['lowest']}%",
            styles["Normal"],
        ),
        Spacer(1, 16),
    ]

    table_data = [["Rank", "Candidate", "Match Score (%)", "Recommendation"]]
    for s in report["scores"]:
        table_data.append([s["rank_position"], s["full_name"], s["match_score"], s["recommendation"]])

    table = Table(table_data, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#6C5CE7")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
    ]))
    elements.append(table)
    doc.build(elements)
    buf.seek(0)

    return Response(buf.getvalue(), mimetype="application/pdf",
                     headers={"Content-Disposition": f"attachment;filename=report_job_{job_id}.pdf"})


# ======================================================================
# ML Classifier insight page (transparency for the viva / demo)
# ======================================================================
@app.route("/ml-insights")
@login_required
def ml_insights():
    metrics = ml_classifier.get_saved_metrics()
    return render_template("ml_insights.html", metrics=metrics,
                            model_available=ml_classifier.is_model_available(),
                            use_ml_classifier=Config.USE_ML_CLASSIFIER)


# ======================================================================
# Error handlers
# ======================================================================
@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


@app.errorhandler(413)
def too_large(e):
    flash("File too large. Maximum upload size is 25 MB.", "danger")
    return redirect(request.referrer or url_for("dashboard"))


@app.errorhandler(429)
def rate_limited(e):
    flash("Too many attempts. Please wait a moment and try again.", "warning")
    return redirect(url_for("login"))


if __name__ == "__main__":
    try:
        init_db()
    except Exception as exc:
        logger.warning("Could not verify/create database automatically: %s", exc)
        logger.warning("Make sure MySQL is running and database/schema.sql has been imported.")
    app.run(debug=Config.DEBUG, host="0.0.0.0", port=int(os.environ.get("PORT", 5001)))
