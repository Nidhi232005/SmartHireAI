"""
config.py
---------
Central configuration for the AI Resume Screening & Recruitment Portal.
Values are loaded from environment variables (via a .env file in
development) so secrets are never hard-coded in source control.
"""

import os
from dotenv import load_dotenv

load_dotenv()  # loads variables from a .env file if present

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    # ---- Flask core ----
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-secret-key-in-production")
    DEBUG = os.environ.get("FLASK_DEBUG", "1") == "1"

    # ---- MongoDB connection ----
    MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/")
    MONGO_DB = os.environ.get("MONGO_DB", "resume_screening_db")

    # ---- File uploads ----
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
    ALLOWED_EXTENSIONS = {"pdf", "docx"}
    ALLOWED_BULK_EXTENSIONS = {"zip"}
    MAX_CONTENT_LENGTH = 25 * 1024 * 1024  # 25 MB per request (bulk ZIP uploads)

    # ---- AI / NLP ----
    SHORTLIST_THRESHOLD = 60.0
    REJECT_THRESHOLD = 35.0
    USE_ML_CLASSIFIER = os.environ.get("USE_ML_CLASSIFIER", "0") == "1"
    USE_SEMANTIC_MATCHING = os.environ.get("USE_SEMANTIC_MATCHING", "1") == "1"
    COSINE_WEIGHT = 0.45
    SEMANTIC_WEIGHT = 0.15
    SKILL_WEIGHT = 0.40

    # ---- Session ----
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 4  # 4 hours

    # ---- Rate limiting ----
    RATELIMIT_STORAGE_URI = os.environ.get("RATELIMIT_STORAGE_URI", "memory://")
    LOGIN_RATE_LIMIT = os.environ.get("LOGIN_RATE_LIMIT", "10 per minute")

    # ---- Email notifications (Flask-Mail) ----
    MAIL_ENABLED = os.environ.get("MAIL_ENABLED", "0") == "1"
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "smtp.gmail.com")
    MAIL_PORT = int(os.environ.get("MAIL_PORT", 587))
    MAIL_USE_TLS = os.environ.get("MAIL_USE_TLS", "1") == "1"
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "")
    MAIL_DEFAULT_SENDER = os.environ.get("MAIL_DEFAULT_SENDER", "noreply@resumeai.local")

    # ---- Logging ----
    LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
    LOG_FILE = os.path.join(BASE_DIR, "logs", "app.log")
