/* candidates.js — fetches and displays resume text in a modal preview. */

function previewResume(candidateId) {
  const modalEl = document.getElementById("previewModal");
  const textEl = document.getElementById("previewText");
  const modal = bootstrap.Modal.getOrCreateInstance(modalEl);

  textEl.textContent = "Loading resume text...";
  modal.show();

  fetch(`/candidates/${candidateId}/preview`)
    .then((res) => res.json())
    .then((data) => { textEl.textContent = data.raw_text || data.error || "No content available."; })
    .catch(() => { textEl.textContent = "Failed to load resume preview."; });
}
