/* kanban.js — drag-and-drop hiring pipeline board. Dragging a card into a
   new column sends an AJAX PATCH-style POST (as JSON) to update the
   candidate's status, using the CSRF-aware fetch helper from main.js. */

(() => {
  const cards = document.querySelectorAll(".kanban-card");
  const columns = document.querySelectorAll(".kanban-cards");
  if (!cards.length || !columns.length) return;

  let draggedCard = null;

  cards.forEach((card) => {
    card.addEventListener("dragstart", () => {
      draggedCard = card;
      card.classList.add("dragging");
    });
    card.addEventListener("dragend", () => {
      card.classList.remove("dragging");
      draggedCard = null;
    });
  });

  columns.forEach((column) => {
    column.addEventListener("dragover", (e) => {
      e.preventDefault();
      column.classList.add("drag-over");
    });
    column.addEventListener("dragleave", () => column.classList.remove("drag-over"));

    column.addEventListener("drop", (e) => {
      e.preventDefault();
      column.classList.remove("drag-over");
      if (!draggedCard) return;

      const candidateId = draggedCard.getAttribute("data-candidate-id");
      const newStatus = column.closest(".kanban-column").getAttribute("data-status");
      const oldColumn = draggedCard.parentElement;

      column.appendChild(draggedCard);
      updateColumnCounts();

      csrfFetch(`/candidates/${candidateId}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.error) throw new Error(data.error);
          showToast(`Candidate moved to ${newStatus.charAt(0) + newStatus.slice(1).toLowerCase()}.`);
        })
        .catch(() => {
          // Roll back the move on failure
          oldColumn.appendChild(draggedCard);
          updateColumnCounts();
          showToast("Could not update candidate status. Please try again.");
        });
    });
  });

  function updateColumnCounts() {
    document.querySelectorAll(".kanban-column").forEach((col) => {
      const count = col.querySelectorAll(".kanban-card").length;
      col.querySelector(".kanban-count").textContent = count;
    });
  }
})();
