/* upload.js — drag-and-drop resume upload, client-side file validation,
   file list rendering, and a simulated progress bar while the form
   submits (individual-files tab only; the bulk ZIP tab is a plain form). */

(() => {
  const dropzone = document.getElementById("dropzone");
  const fileInput = document.getElementById("resumeInput");
  const fileListEl = document.getElementById("fileList");
  const submitBtn = document.getElementById("submitUploadBtn");
  const form = document.getElementById("uploadForm");
  const progressWrap = document.getElementById("uploadProgressWrap");
  const progressBar = document.getElementById("uploadProgressBar");

  if (!dropzone || !fileInput) return;

  const ALLOWED_EXT = ["pdf", "docx"];
  const MAX_SIZE_MB = 10;
  let dataTransfer = new DataTransfer();

  dropzone.addEventListener("click", () => fileInput.click());

  ["dragenter", "dragover"].forEach((evt) =>
    dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.add("dragover"); })
  );
  ["dragleave", "drop"].forEach((evt) =>
    dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.remove("dragover"); })
  );
  dropzone.addEventListener("drop", (e) => handleFiles(e.dataTransfer.files));
  fileInput.addEventListener("change", () => handleFiles(fileInput.files));

  function handleFiles(fileListRaw) {
    Array.from(fileListRaw).forEach((file) => {
      const ext = file.name.split(".").pop().toLowerCase();
      if (!ALLOWED_EXT.includes(ext)) { showToast(`"${file.name}" was skipped — only PDF and DOCX are supported.`); return; }
      if (file.size > MAX_SIZE_MB * 1024 * 1024) { showToast(`"${file.name}" was skipped — file exceeds ${MAX_SIZE_MB}MB.`); return; }
      dataTransfer.items.add(file);
    });
    fileInput.files = dataTransfer.files;
    renderFileList();
  }

  function renderFileList() {
    fileListEl.innerHTML = "";
    Array.from(dataTransfer.files).forEach((file, idx) => {
      const ext = file.name.split(".").pop().toLowerCase();
      const iconClass = ext === "pdf" ? "fa-file-pdf" : "fa-file-word";
      const item = document.createElement("div");
      item.className = "file-list-item";
      item.innerHTML = `
        <i class="fa-solid ${iconClass}"></i>
        <span>${file.name}</span>
        <span class="text-muted small">(${(file.size / 1024).toFixed(0)} KB)</span>
        <i class="fa-solid fa-xmark remove-file" data-idx="${idx}"></i>
      `;
      fileListEl.appendChild(item);
    });

    fileListEl.querySelectorAll(".remove-file").forEach((btn) => {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.getAttribute("data-idx"), 10);
        const newDT = new DataTransfer();
        Array.from(dataTransfer.files).forEach((f, i) => { if (i !== idx) newDT.items.add(f); });
        dataTransfer = newDT;
        fileInput.files = dataTransfer.files;
        renderFileList();
      });
    });

    submitBtn.disabled = dataTransfer.files.length === 0;
  }

  if (form) {
    form.addEventListener("submit", () => {
      if (dataTransfer.files.length === 0) return;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
      progressWrap.classList.remove("d-none");

      let pct = 0;
      const interval = setInterval(() => {
        pct = Math.min(pct + Math.random() * 12, 92);
        progressBar.style.width = pct + "%";
      }, 300);
      window.addEventListener("beforeunload", () => clearInterval(interval));
    });
  }
})();
