/* main.js — global UI behaviors: sidebar toggle, dark mode, password
   visibility toggle, toast helper, and a CSRF-aware fetch wrapper used
   by other page scripts (kanban.js, candidates.js). */

function getCsrfToken() {
  const meta = document.querySelector('meta[name="csrf-token"]');
  return meta ? meta.getAttribute("content") : "";
}

/** fetch() wrapper that automatically attaches the CSRF token header
 * for state-changing requests, so AJAX calls pass Flask-WTF's CSRF check. */
function csrfFetch(url, options = {}) {
  const opts = { ...options, headers: { ...(options.headers || {}), "X-CSRFToken": getCsrfToken() } };
  return fetch(url, opts);
}

document.addEventListener("DOMContentLoaded", () => {
  const sidebar = document.getElementById("sidebar");
  const sidebarToggle = document.getElementById("sidebarToggle");
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener("click", () => sidebar.classList.toggle("open"));
  }

  const root = document.documentElement;
  const darkModeToggle = document.getElementById("darkModeToggle");
  const savedTheme = localStorageSafeGet("resumeai-theme");
  if (savedTheme) root.setAttribute("data-theme", savedTheme);

  if (darkModeToggle) {
    updateDarkIcon();
    darkModeToggle.addEventListener("click", () => {
      const isDark = root.getAttribute("data-theme") === "dark";
      const next = isDark ? "light" : "dark";
      root.setAttribute("data-theme", next);
      localStorageSafeSet("resumeai-theme", next);
      updateDarkIcon();
    });
  }
  function updateDarkIcon() {
    const icon = darkModeToggle.querySelector("i");
    const isDark = root.getAttribute("data-theme") === "dark";
    icon.className = isDark ? "fa-solid fa-sun" : "fa-solid fa-moon";
  }

  document.querySelectorAll(".toggle-password").forEach((icon) => {
    icon.addEventListener("click", () => {
      const targetId = icon.getAttribute("data-target");
      const input = document.getElementById(targetId);
      if (!input) return;
      const isPassword = input.type === "password";
      input.type = isPassword ? "text" : "password";
      icon.classList.toggle("fa-eye");
      icon.classList.toggle("fa-eye-slash");
    });
  });

  document.querySelectorAll(".flash-alert").forEach((alertEl) => {
    setTimeout(() => {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alertEl);
      bsAlert.close();
    }, 6000);
  });
});

function localStorageSafeGet(key) {
  try { return window.localStorage ? localStorage.getItem(key) : null; }
  catch (e) { return null; }
}
function localStorageSafeSet(key, value) {
  try { if (window.localStorage) localStorage.setItem(key, value); }
  catch (e) { /* no-op */ }
}

function showToast(message, type = "info") {
  const container = document.getElementById("toastContainer");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = "custom-toast";
  toast.innerHTML = `<i class="fa-solid fa-circle-info"></i> ${message}`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
